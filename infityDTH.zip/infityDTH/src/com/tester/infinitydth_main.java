package com.tester;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


import com.bean.customer;
import com.bean.function;
import com.bean.logcred;
import com.dao.databaselogin;

public class infinitydth_main {

	public static void main(String[] args) throws SQLException{
		// TODO Auto-generated method stub
		String jdbcURL = "jdbc:derby:testdb4;create=true";
		Connection connection = DriverManager.getConnection(jdbcURL);
		System.out.println("The connection is established");
		databaselogin dao=new databaselogin();
		try{
			dao.createTables(connection);
		}
		catch(Exception e)
		{
		}
		function fc=new function();
		Scanner sc=new Scanner(System.in);
		System.out.println("hello welcome to infityDTH");
		boolean bool=true;
		while(bool)
		{
			System.out.println("to login press 1 to sign up press 2 to exit press 3");
			int value=sc.nextInt();
			switch(value)
			{
			case 1:
				System.out.println("Enter the user name:");
				String username=sc.next();
				System.out.println("Enter the password:");
				String password=sc.next();
				int[] valid=dao.Validateuser(connection, username ,password);
				while(valid[0]==0 || valid[0]==5)
				{
					System.out.println("wrong username/password entered retry");
					System.out.println("Enter the user name:");
					username=sc.next();
					System.out.println("Enter the password:");
					password=sc.next();
					valid=dao.Validateuser(connection, username ,password);
				}
				switch(valid[0])
				{
				case 1:
					fc.admin(connection);
					bool=false;
					break;
				case 2:
					fc.operator(connection, valid[1]);
					bool=false;
					break;
				case 3:
					fc.Retailer(connection);
					bool=false;
					break;
				case 4:
					fc.customer(connection, valid[1]);
					bool=false;
					break;
				case 8:
					System.out.println("change your default password");
					System.out.println("enter new password");
					String p=sc.next();
					System.out.println("confirm password");
					String cp=sc.next();
					while(!(p.contentEquals(cp))){
						System.out.println("password does not match");
						System.out.println("enter new password");
						p=sc.next();
						System.out.println("confirm password");
						cp=sc.next();
					}
					int res=dao.Changepassword(connection, valid[1], p);
					valid=dao.Validateuser(connection, username ,p);
					if (res==0)
					{
					System.out.println("password changed");
					}
					break;
				default:
					break;
					
				}
			break;
			case 2:
				int id3=dao.generateid();
				System.out.println("First Name");
				String firstname=sc.next();
				System.out.println("Last Name");
				String lastname=sc.next();
				System.out.println("Email ID");
				String emailid=sc.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phonenumber=sc.next();
				System.out.println("Address1");
				String address1=sc.next();
				System.out.println("Address2");
				String address2=sc.next();
				System.out.println("landmark");
				String landmark=sc.next();
				System.out.println("Pincode");
				String pincode=sc.next();
				System.out.println("City");
				String city=sc.next();
				System.out.println("State");
				String state=sc.next();
				SimpleDateFormat form=new SimpleDateFormat("dd/mm/yy");
				Date date=new Date();
				String customercreationdate=form.format(date);
				try{
				customer c=new customer(id3, firstname, lastname, emailid, phonenumber, address1, address2, landmark, pincode, city, state, customercreationdate, null, null);
				dao.insertCustomer(connection, c);
				logcred l=new logcred(id3, lastname, "Defpass@123", "customer");
				System.out.println("your default password is Defpass@123");
				dao.insertLoginCred(connection, l);
				}
				catch(Exception e)
				{
					id3=dao.generateid();
				}
				break;
			case 3:
			{
				bool=false;
				connection.close();
				break;
			}
			default:
				System.out.println("enter correct input");
				break;

	}
	}
	}
}


