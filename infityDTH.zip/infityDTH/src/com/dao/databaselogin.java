package com.dao;

import java.sql.Statement;

import com.bean.CustMangSBT;
import com.bean.CustPurchaseChanlPkg;
import com.bean.CustPurchaseSBT;
import com.bean.OperCustCharg;
import com.bean.OperMangChannel;
import com.bean.OperMangPackg;
import com.bean.customer;
import com.bean.inventorylist;
import com.bean.logcred;
import com.bean.operator;
import com.bean.retailer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class databaselogin {
	//create records
	int id=2;
	public void createTables(Connection connection)throws SQLException
	{
		String sql="create table logincred(id int, username varchar(30), password varchar(30), designation varchar(10), primary key(id))";
		Statement stmt = connection.createStatement();
		stmt.execute(sql);
		String admindata="insert into logincred(id,username,password,designation) values(?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(admindata);
		pstmt.setInt(1, 1);
		pstmt.setString(2, "admin");
		pstmt.setString(3, "Defpass@123");
		pstmt.setString(4, "admin");
		pstmt.executeUpdate();
		String customerTable="create table customerTable(id int primary key,Firstname varchar(30),Lastname varchar(30),Emailid varchar(100),phonenumber char(13),address1 varchar(100),address2 varchar(100),landmark varchar(100),pincode char(10),city varchar(50),state varchar(50),customercreationdate varchar(10), operatorname varchar(100),retailername varchar(100) )";
		Statement stmt1 = connection.createStatement();
		stmt1.execute(customerTable);
		String retailerTable="create table retailerTable(id int primary key,name varchar(100),contactno1 varchar(13),contactno2 varchar(13),address1 varchar(100),address2 varchar(100),pincode varchar(10),city varchar(50),state varchar(50),settopboxlimit int,creditlimit int,commissionpercentage int,servicecharge int,inventorylist int,retailercreationdate varchar(100), totalcostofinventory int)";
		Statement stmt2 = connection.createStatement();
		stmt2.execute(retailerTable);
		String operatorTable="create table operatorTable(id int primary key ,Firstname varchar(30),Lastname varchar(30),Emailid varchar(100), Phonenumber varchar(13),shifttimestart varchar(10),shifttimeend varchar(10), noofcustomersmanaged int,creationdate varchar(10),totalnoofactivecustomers int)";
		Statement stmt3 = connection.createStatement();
		stmt3.execute(operatorTable);
		String inventoryTable="create table inventoryTable(id int primary key,settopboxtype varchar(30),serialnumber int,macid int, remoteassetid int,dishassetid int,settopboxstatus varchar(30))";
		Statement stmt4 = connection.createStatement();
		stmt4.execute(inventoryTable);
		createTableM2T1(connection);
		createTableM2T2(connection);
		createTableM2T3(connection);
		createTableM3T1(connection);
		createTableM3T2(connection);
		createTableM3T3(connection);
		
	}
	
	
	
	//display records
	public void displayOperatorRecords(Connection connection,int id) throws SQLException
	{
		String sql = "select * from operatorTable where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1,id);
		
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("First Name: %s", resultObj.getString("Firstname")));
			System.out.println(String.format("Last Name: %s", resultObj.getString("Lastname")));
			System.out.println(String.format("Email ID: %s", resultObj.getString("Emailid")));
			System.out.println(String.format("Phone Number: %s", resultObj.getString("Phonenumber")));
			System.out.println(String.format("Shift Time Start: %s", resultObj.getString("shifttimestart")));
			System.out.println(String.format("Shift Time End: %s", resultObj.getString("shifttimeend")));
			System.out.println(String.format("Max no of Customers to be managed: %d", resultObj.getInt("noofcustomersmanaged")));
			System.out.println(String.format("Creation Date: %s", resultObj.getString("creationdate")));
			System.out.println(String.format("Total no.of Active Customers: %d", resultObj.getInt("totalnoofactivecustomers")));
		}
	}
	public void displayRetailerRecords(Connection connection,int id) throws SQLException
	{
		String sql = "select * from retailerTable where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1,id);
		
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("Name: %s", resultObj.getString("name")));
			System.out.println(String.format("Contact no1: %s", resultObj.getString("contactno1")));
			System.out.println(String.format("Contact no2: %s", resultObj.getString("contactno2")));
			System.out.println(String.format("Address 1: %s", resultObj.getString("address1")));
			System.out.println(String.format("Address 2: %s", resultObj.getString("address2")));
			System.out.println(String.format("pincode: %s", resultObj.getString("pincode")));
			System.out.println(String.format("city: %s", resultObj.getString("city")));
			System.out.println(String.format("state: %s", resultObj.getString("state")));
			System.out.println(String.format("Set Top Box Limit: %d", resultObj.getInt("settopboxlimit")));
			System.out.println(String.format("Credit Limit: %d", resultObj.getInt("creditlimit")));
			System.out.println(String.format("Commission percentage on sale of goods: %d", resultObj.getInt("commissionpercentage")));
			System.out.println(String.format("Service Charge: %d", resultObj.getInt("servicecharge")));
			System.out.println(String.format("inventorylist: %d", resultObj.getInt("inventorylist")));
			System.out.println(String.format("Retailer Creation Date: %s", resultObj.getString("retailercreationdate")));
			System.out.println(String.format("Total Cost of Inventory: %d", resultObj.getInt("totalcostofinventory")));
			
			
		}
	}
	public void displayCustomerRecords(Connection connection,int id) throws SQLException
	{
		String sql = "select * from customerTable where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1,id);
		
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("First Name: %s", resultObj.getString("Firstname")));
			System.out.println(String.format("Last Name: %s", resultObj.getString("Lastname")));
			System.out.println(String.format("Email ID: %s", resultObj.getString("Emailid")));
			System.out.println(String.format("Phone Number: %s", resultObj.getString("phonenumber")));
			System.out.println(String.format("Address 1: %s", resultObj.getString("address1")));
			System.out.println(String.format("Address 2: %s", resultObj.getString("address2")));
			System.out.println(String.format("Landmark: %s", resultObj.getString("landmark")));
			System.out.println(String.format("Pincode: %s", resultObj.getString("pincode")));
			System.out.println(String.format("City: %s", resultObj.getString("city")));
			System.out.println(String.format("State: %s", resultObj.getString("state")));
			System.out.println(String.format("Customer Creation Date: %s", resultObj.getString("customercreationdate")));
			System.out.println(String.format("Operator Name: %s", resultObj.getString("operatorname")));
			System.out.println(String.format("Retailer Name: %s", resultObj.getString("retailername")));
			
			
		}
	}
	//module 2 display 
	
	
	//insert records
	public void insertLoginCred(Connection connection,logcred l)throws SQLException
	{
		String sql="insert into logincred(id,username,password,designation) values (?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setInt(1, l.getId());
		pstmt.setString(2, l.getUsername());
		pstmt.setString(3, l.getPassword());
		pstmt.setString(4, l.getDesignation());
		pstmt.executeUpdate();
	}
	public int insertOperator(Connection connection,operator o)throws SQLException
	{
		String sql="insert into operatorTable(id,Firstname,Lastname,Emailid,Phonenumber,shifttimestart,shifttimeend,noofcustomersmanaged,creationdate,totalnoofactivecustomers) values (?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setInt(1, o.getId());
		pstmt.setString(2, o.getFirstName());
		pstmt.setString(3, o.getLastName());
		pstmt.setString(4, o.getEmailId());
		pstmt.setString(5, o.getPhonenumber());
		pstmt.setString(6, o.getShifttimestart());
		pstmt.setString(7, o.getShifttimeend());
		pstmt.setInt(8, o.getNoofcustomersmanaged());
		pstmt.setString(9, o.getCreationdate());
		pstmt.setInt(10,o.getTotalnoofactivecustomers());
		int rows=pstmt.executeUpdate();
		return rows;
	}
	public int insertCustomer(Connection connection,customer c)throws SQLException
	{
		String sql="insert into customerTable(id,Firstname,Lastname,Emailid,Phonenumber,address1,address2,landmark,pincode,city,state,customercreationdate,operatorname,retailername) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setInt(1, c.getId());
		pstmt.setString(2, c.getFirstName());
		pstmt.setString(3, c.getLastName());
		pstmt.setString(4, c.getEmailId());
		pstmt.setString(5, c.getPhoneNumber());
		pstmt.setString(6, c.getAddress1());
		pstmt.setString(7, c.getAddress2());
		pstmt.setString(8, c.getLandmark());
		pstmt.setString(9, c.getPincode());
		pstmt.setString(10, c.getCity());
		pstmt.setString(11, c.getState());
		pstmt.setString(12, c.getCustomercreationdate());
		pstmt.setString(13, c.getOperatorname());
		pstmt.setString(14, c.getRetailername());
		int rows=pstmt.executeUpdate();
		return rows;
	}
	public int insertRetailer(Connection connection,retailer r)throws SQLException
	{
		String sql="insert into RetailerTable(id,name,contactno1,contactno2,address1,address2,pincode,city,state,settopboxlimit,creditlimit,commissionpercentage,servicecharges,inventorylist,retailercreationdate, totalcostofinventory) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setInt(1, r.getId());
		pstmt.setString(2, r.getName());
		pstmt.setString(3, r.getContactno1());
		pstmt.setString(4, r.getContactno2());
		pstmt.setString(5, r.getAddress1());
		pstmt.setString(6, r.getAddress2());
		pstmt.setString(7, r.getPincode());
		pstmt.setString(8, r.getCity());
		pstmt.setString(9, r.getState());
		pstmt.setInt(10, r.getSettopboxlimit());
		pstmt.setInt(11, r.getCreditlimit());
		pstmt.setInt(12, r.getCommissionpercentage());
		pstmt.setInt(13, r.getServicecharge());
		pstmt.setInt(14, r.getInventorylist());
		pstmt.setString(15, r.getRetailercreationdate());
		pstmt.setInt(16, r.getTotalcostofinventory());
		int rows=pstmt.executeUpdate();
		return rows;
	}
	public int insertInventorylist(Connection connection,inventorylist i) throws SQLException
	{
		String sql="insert into inventoryTable(id,settopboxtype,serialnumber,macid,remoteassetid,dishassetid,settopboxstatus) values(?,?,?,?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setInt(1, i.getId());
		pstmt.setString(2, i.getSettopboxtype());
		pstmt.setInt(3, i.getSerialnumber());
		pstmt.setInt(4, i.getMacid());
		pstmt.setInt(5, i.getRemoteassetid());
		pstmt.setInt(6, i.getDishassetid());
		pstmt.setString(7, i.getSettopboxstatus());
		int rows=pstmt.executeUpdate();
		return rows;
	}
	//module 2 insert
	
	
	//delete records
	public void deleteDatafromoperator(Connection connection, int id) throws SQLException
	{
		String sql = "delete from operatorTable where id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	public void deleteDatafromcustomer(Connection connection, int id) throws SQLException
	{
		String sql = "delete from customerTable where id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	public void deleteDatafromretailer(Connection connection, int id) throws SQLException
	{
		String sql = "delete from retailerTable where id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	public void deleteDatafromlogincred(Connection connection,int id) throws SQLException
	{
		String sql = "delete from logincred where id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	//module 2 delete
	
	//update records
	public int updateDatainoperator(Connection connection,String firstname,String lastname,String emailid,String phonenumber,String shifttimestart,String shifttimeend,int noofcustomerstobemanaged,String creationdate,int id) throws SQLException
	{
		String sql="update operatorTable set Firstname=?,Lastname=?,Emailid=?,Phonenumber=?,shifttimestart=?,shifttimeend=?,noofcustomersmanaged=?,creationdate=? where id=?";
		PreparedStatement pstmt=connection.prepareStatement(sql);
		pstmt.setString(1, firstname);
		pstmt.setString(2, lastname);
		pstmt.setString(3,emailid);
		pstmt.setString(4,phonenumber);
		pstmt.setString(5,shifttimestart);
		pstmt.setString(6,shifttimeend);
		pstmt.setInt(7,noofcustomerstobemanaged);
		pstmt.setString(8,creationdate);
		pstmt.setInt(9, id);
		int updated=pstmt.executeUpdate();
		return updated;
	}
	public int updateDataincustomer(Connection connection,String firstname,String lastname,String emailid,String phonenumber,String address1,String address2,String landmark,String pincode,String city,String state,String operatorname,String retailername,int id) throws SQLException
	{
		String sql="update customerTable set Firstname=?,Lastname=?,Emailid=?,Phonenumber=?,address1=?,address2=?,landmark=?,pincode=?,city=?,state=?,operatorname=?,retailername=? where id=?";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setString(1, firstname);
		pstmt.setString(2, lastname);
		pstmt.setString(3,emailid);
		pstmt.setString(4,phonenumber);
		pstmt.setString(5,address1);
		pstmt.setString(6,address2);
		pstmt.setString(7,landmark);
		pstmt.setString(8,pincode);
		pstmt.setString(9, city);
		pstmt.setString(10,state);
		pstmt.setString(11, operatorname);
		pstmt.setString(12,retailername);
		int rows=pstmt.executeUpdate();
		return rows;
	}
	public int updateDatainretailer(Connection connection,String name,String contactno1,String contactno2,String address1,String address2,String pincode,String city,String state,int settopboxlimit,int creditlimit,int commissionpercentage,int servicecharge,int inventorylist,int id) throws SQLException
	{
		String sql="update RetailerTable set name=?,contactno1=?,contactno2=?,address1=?,address2=?,pincode=?,city=?,state=?,settopboxlimit=?,creditlimit=?,commissionpercentage=?,servicecharges=?,inventorylist=? where id=?";
		PreparedStatement pstmt=connection.prepareStatement(sql); 
		pstmt.setString(1, name);
		pstmt.setString(2, contactno1);
		pstmt.setString(3, contactno2);
		pstmt.setString(4, address1);
		pstmt.setString(5, address2);
		pstmt.setString(6, pincode);
		pstmt.setString(7, city);
		pstmt.setString(8, state);
		pstmt.setInt(9, settopboxlimit);
		pstmt.setInt(10, creditlimit);
		pstmt.setInt(11, commissionpercentage);
		pstmt.setInt(12, servicecharge);
		pstmt.setInt(13, inventorylist);
		
		int rows=pstmt.executeUpdate();
		return rows;
	}
	public void updatetotalnoofactivecustomersinoperator(Connection connection,int id) throws SQLException 
	{
		String sql1="select totalnoofactivecustomers from operatortable where id=?";
		String sql2="select noofcustomerstobemanaged from operatortable where id=?";
		String sql="update operatorTable set totalnoofactivecustomers=? where id=?";
		PreparedStatement ps=connection.prepareStatement(sql1);
		ps.setInt(1,id);
		ResultSet obj=ps.executeQuery(sql1);
		PreparedStatement ps1=connection.prepareStatement(sql2);
		ps1.setInt(1,id);
		ResultSet obj1=ps1.executeQuery(sql2);
		int a=obj.getInt("totalnoofactivecustomers");
		int b=obj1.getInt("noofcustomerstobemanaged");
		PreparedStatement pstmt=connection.prepareStatement(sql);
		if(a+1>b)
			System.out.println("maximum Limit Reached");
		else{
		pstmt.setInt(1, a+1);
		pstmt.setInt(2,id);
		obj=pstmt.executeQuery();}
	}
	//module 2 update
	
	//change password
	public int Changepassword(Connection connection,int id,String password1) throws SQLException
	{
		String sql="update logincred set password=? where id=?";
		PreparedStatement stmt=connection.prepareStatement(sql);  
		stmt.setString(1,password1);//1 specifies the first parameter in the query i.e. name  
		stmt.setInt(2,id); 
		  
		int i=stmt.executeUpdate();
		System.out.println(i+" records updated");
		return i;
	}
	
	public int[] Validateuser(Connection connection,String sc,String pa) throws SQLException

	{
		int[] ans=new int[2];
		String defaultpassword=new String("Defpass@123");
		String admin=new String("admin");
		String operator=new String("operator");
		String retailer=new String("retailer");
		
		String sql="select id,password,designation from logincred where username=?";
		PreparedStatement a=connection.prepareStatement(sql);
		a.setString(1, sc);
		ResultSet obj=a.executeQuery();
		int idval=0;
		String pass = null;
		String designation = null;
		while(obj.next())
		{
			idval=Integer.parseInt(String.format("%d", obj.getInt("id")));
			pass=String.format("%s", obj.getString("password"));
			designation=String.format("%s", obj.getString("designation"));
		}
		if(defaultpassword.equals(pa))
		{
			ans[0]=8;
			ans[1]=idval;
		}
		else if(pass.equals(pa))
		{
			if(designation.equals(admin))
			{
				ans[0]=1;
				ans[1]=idval;
			}
			else if(designation.equals(operator))
			{
				ans[0]=2;
				ans[1]=idval;
			}
			else if(designation.equals(retailer))
			{
				ans[0]=3;
				ans[1]=idval;
			}
			else
			{
					ans[0]=4;
					ans[1]=idval;
			}
		}
		else
		{
			ans[0]=0;
			ans[1]=0;
		}
		a.close();
		return ans;
		
	}
	public int generateid() throws SQLException
	{
		
		return id++;
	}
	public String getoperatorname(Connection connection,int id) throws SQLException
	{
		String sql="select lastname from operatortable where id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setInt(1,id);
		ResultSet resultObj = ps.executeQuery();
		String lastname=null;
		while(resultObj.next())
		{
			lastname=String.format("%s", resultObj.getString("lastname"));
		}
		return lastname;
	}

	public void displayRecordsM2T1(Connection connection,int id) throws SQLException
	{
		String sql = "select SBTtype,SBTfeatures,Length,Breadth,Width,Price,InstallationCharges,UpgradationCharges,Discount,BillingType,RefundableDepositeAmmount,SBTinventoryDetails,SBTtypeMatch,SBTserialNumber,SBTmacId,RemoteControlAssetId,DishAssetId,SBTstatus from CustomerM2T1 where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1,id);
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("SBTtype: %s", resultObj.getString("SBTtype")));
			System.out.println(String.format("SBTfeatures: %s", resultObj.getString("SBTfeatures")));
			System.out.println(String.format("Length: %s", resultObj.getString("Length")));
			System.out.println(String.format("Breadth: %s", resultObj.getString("Breadth")));
			System.out.println(String.format("Width: %s", resultObj.getString("Width")));
			System.out.println(String.format("Price: %s", resultObj.getString("Price")));
			System.out.println(String.format("InstallationCharges: %s", resultObj.getString("InstallationCharges")));
			System.out.println(String.format("UpgradationCharges: %s", resultObj.getString("UpgradationCharges")));
			System.out.println(String.format("Discount: %s", resultObj.getString("Discount")));
			System.out.println(String.format("BillingType: %s", resultObj.getString("BillingType")));
			System.out.println(String.format("RefundableDepositeAmmount: %s", resultObj.getString("RefundableDepositeAmmount")));
			System.out.println(String.format("SBTinventoryDetails: %s", resultObj.getString("SBTinventoryDetails")));
			System.out.println(String.format("SBTtypeMatch: %s", resultObj.getString("SBTtypeMatch")));
			System.out.println(String.format("SBTserialNumber: %s", resultObj.getString("SBTserialNumber")));
			System.out.println(String.format("SBTmacId: %s", resultObj.getString("SBTmacId")));
			System.out.println(String.format("RemoteControlAssetId: %s", resultObj.getString("RemoteControlAssetId")));
			System.out.println(String.format("DishAssetId: %s", resultObj.getString("DishAssetId")));
			System.out.println(String.format("SBTstatus: %s", resultObj.getString("SBTstatus")));
		}
	}
	
	public void createTableM2T1(Connection connection) throws SQLException
	{
		String sql = "create table CustomerM2T1(Id int primary key,SBTtype varchar(25),SBTfeatures varchar(25),Length varchar(25),Breadth varchar(25),Width varchar(25),Price varchar(25),InstallationCharges varchar(25),UpgradationCharges varchar(25),Discount varchar(25),BillingType varchar(25),RefundableDepositeAmmount varchar(25),SBTinventoryDetails  varchar(25),SBTtypeMatch varchar(25),SBTserialNumber varchar(25),SBTmacId varchar(25),RemoteControlAssetId varchar(25),DishAssetId varchar(25),SBTstatus varchar(25) )";
		Statement stmt = connection.createStatement();
		
		stmt.execute(sql);
	}
	
	public int insertDataM2T1(Connection connection, CustMangSBT e) throws SQLException
	{
		String sql = "insert into CustomerM2T1 (Id,SBTtype,SBTfeatures,Length,Breadth,Width,Price,InstallationCharges,UpgradationCharges,Discount,BillingType,RefundableDepositeAmmount,SBTinventoryDetails,SBTtypeMatch,SBTserialNumber,SBTmacId,RemoteControlAssetId,DishAssetId,SBTstatus) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, e.getId());
		pstmt.setString(2, e.getSBTtype());
		pstmt.setString(3, e.getSBTfeatures());
		pstmt.setString(4, e.getLength());
		pstmt.setString(5, e.getBreadth());
		pstmt.setString(6, e.getWidth());
		pstmt.setString(7, e.getPrice());
		pstmt.setString(8, e.getInstallationCharges());
		pstmt.setString(9, e.getUpgradationCharges());
		pstmt.setString(10, e.getDiscount());
		pstmt.setString(11, e.getBillingType());
		pstmt.setString(12, e.getRefundableDepositeAmmount());
		pstmt.setString(13, e.getSBTinventoryDetails());
		pstmt.setString(14, e.getSBTtypeMatch());
		pstmt.setString(15, e.getSBTserialNumber());
		pstmt.setString(16, e.getSBTmacId());
		pstmt.setString(17, e.getRemoteControlAssetId());
		pstmt.setString(18, e.getDishAssetId());
		pstmt.setString(19, e.getSBTstatus());
		int rows=pstmt.executeUpdate();
		return rows;
	}
	
	public int updateDataM2T1(Connection connection,String SBTtype,String SBTfeatures,String Length,String Breadth,String Width,String Price,String InstallationCharges,String UpgradationCharges,String Discount,String BillingType,String RefundableDepositeAmmount,String SBTinventoryDetails,String SBTtypeMatch,String SBTserialNumber,String SBTmacId,String RemoteControlAssetId,String DishAssetId,String SBTstatus,int Id) throws SQLException
	{
		String sql="update CustomerM2T1 set SBTtype =?,SBTfeatures =?,Length =?,Breadth =?,Width =?,Price =?,Breadth =?,InstallationCharges =?,UpgradationCharges =?,Discount =?,BillingType =?,RefundableDepositeAmmount =?,SBTinventoryDetails =?,SBTtypeMatch =?,SBTserialNumber =?,SBTmacId =?,RemoteControlAssetId =?,DishAssetId =?,SBTstatus =? where Id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1,SBTtype);
		ps.setString(2,SBTfeatures);
		ps.setString(3, Length);
		ps.setString(4, Breadth);
		ps.setString(5,Width);
		ps.setString(6,Breadth);
		ps.setString(7, InstallationCharges);
		ps.setString(8, UpgradationCharges);
		ps.setString(9,Discount);
		ps.setString(10,BillingType);
		ps.setString(11, RefundableDepositeAmmount);
		ps.setString(12, SBTinventoryDetails);
		ps.setString(13,SBTtypeMatch);
		ps.setString(14,SBTserialNumber);
		ps.setString(15, SBTmacId);
		ps.setString(16, RemoteControlAssetId);
		ps.setString(17,DishAssetId);
		ps.setString(18,SBTstatus);
		ps.setInt(19, id);
		int updated=ps.executeUpdate();
		return updated;
		
		
	}
	
	public void deleteDataM2T1(Connection connection, int Id) throws SQLException
	{
		String sql = "delete from CustomerM2T1 where Id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, Id);
		pstmt.execute();
	}
	
	
	//Module 2 table 2:- Manage Channels
    //for & Access:- admin and operator

	
	 
	
	public void displayRecordsM2T2(Connection connection,int id) throws SQLException
	{
		String sql = "select ChannelName,ChannelBand,VideoCarrierFrequency,AudioCarrierFrequency,ChannelChargeType,ChannelTransmissionType,ChannelCharge from CustomerM2T2 where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1, id);
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("ChannelName: %s", resultObj.getString("ChannelName")));
			System.out.println(String.format("ChannelBand: %s", resultObj.getString("ChannelBand")));
			System.out.println(String.format("VideoCarrierFrequency: %s", resultObj.getString("VideoCarrierFrequency")));
			System.out.println(String.format("AudioCarrierFrequency: %s", resultObj.getString("AudioCarrierFrequency")));
			System.out.println(String.format("ChannelChargeType: %s", resultObj.getString("ChannelChargeType")));
			System.out.println(String.format("ChannelTransmissionType: %s", resultObj.getString("ChannelTransmissionType")));
			System.out.println(String.format("ChannelCharge: %s", resultObj.getString("ChannelCharge")));
		}
	}
	
	public void createTableM2T2(Connection connection) throws SQLException
	{
		String sql = "create table CustomerM2T2(Id int primary key,ChannelName varchar(25),ChannelBand varchar(25),VideoCarrierFrequency varchar(25),AudioCarrierFrequency varchar(25),ChannelChargeType varchar(25),ChannelTransmissionType varchar(25),ChannelCharge  varchar(25),SBTtype varchar(25),STBmacId varchar(25),STBserialNumber varchar(25),STBprice varchar(25),InstallationCharges varchar(25),Deposit varchar(25),Discount  varchar(25),Tax varchar(25),AmountPayable varchar(25) )  ";
		Statement stmt = connection.createStatement();
		
		stmt.execute(sql);
	}
	
	public int insertDataM2T2(Connection connection, OperMangChannel e) throws SQLException
	{
		
		String sql = "insert into CustomerM2T2 (Id,	ChannelName,ChannelBand,VideoCarrierFrequency,AudioCarrierFrequency,ChannelChargeType,ChannelTransmissionType,ChannelCharge) values (?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, e.getId());
		pstmt.setString(2, e.getChannelName());
		pstmt.setString(3, e.getChannelBand());
		pstmt.setString(4, e.getVideoCarrierFrequency());
		pstmt.setString(5, e.getAudioCarrierFrequency());
		pstmt.setString(6, e.getChannelChargeType());
		pstmt.setString(7, e.getChannelTransmissionType());
		pstmt.setString(8, e.getChannelCharge());
		
		int rows=pstmt.executeUpdate();
		return rows;
	}
	
	public int updateDataM2T2(Connection connection,String 	ChannelName,String ChannelBand,String VideoCarrierFrequency,String AudioCarrierFrequency,String ChannelChargeType,String ChannelTransmissionType,String ChannelCharge,int Id) throws SQLException
	{
		
		

		 
		String sql="update CustomerM2T2 set 	ChannelName =?,ChannelBand =?,VideoCarrierFrequency =?,AudioCarrierFrequency =?,ChannelChargeType =?,ChannelTransmissionType =?,ChannelCharge =? where Id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1,ChannelName);
		ps.setString(2,ChannelBand);
		ps.setString(3, VideoCarrierFrequency);
		ps.setString(4, AudioCarrierFrequency);
		ps.setString(5,ChannelChargeType);
		ps.setString(6,ChannelTransmissionType);
		ps.setString(7, ChannelCharge);
		ps.setInt(8, Id);
		int updated=ps.executeUpdate();
		return updated;
		
		
	}
	
	public void deleteDataM2T2(Connection connection, int Id) throws SQLException
	{
		String sql = "delete from CustomerM2T2 where Id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, Id);
		pstmt.execute();
	}

//Module 2 Table 3. Manage Channel Packages
   //for & Access:- admin and operator
	
	
	public void displayRecordsM2T3(Connection connection,int id) throws SQLException
	{
		String sql = "select 	PackageName,PackageCategory,PackageChargingType,PackageTransmissionType,AddChannels,PackageCost,PackageAvailableFromDate,PackageAvailabletoDate,AddedByDefault from CustomerM2T3 where Id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1, id);
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("PackageName: %s", resultObj.getString("PackageName")));
			System.out.println(String.format("PackageCategory: %s", resultObj.getString("PackageCategory")));
			System.out.println(String.format("PackageChargingType: %s", resultObj.getString("PackageChargingType")));
			System.out.println(String.format("PackageTransmissionType: %s", resultObj.getString("PackageTransmissionType")));
			System.out.println(String.format("AddChannels: %s", resultObj.getString("AddChannels")));
			System.out.println(String.format("PackageCost: %s", resultObj.getString("PackageCost")));
			System.out.println(String.format("PackageAvailableFromDate: %s", resultObj.getString("PackageAvailableFromDate")));
			System.out.println(String.format("PackageAvailabletoDate: %s", resultObj.getString("PackageAvailabletoDate")));
			System.out.println(String.format("AddedByDefault: %s", resultObj.getString("AddedByDefault")));

		}
	}
	
	public void createTableM2T3(Connection connection) throws SQLException
	{
		String sql = "create table CustomerM2T3(Id int primary key,PackageName varchar(25),PackageCategory varchar(25),PackageChargingType varchar(25),PackageTransmissionType varchar(25),AddChannels varchar(25),PackageCost varchar(25),PackageAvailableFromDate varchar(25),PackageAvailabletoDate varchar(25),AddedByDefault varchar(25))";
		Statement stmt = connection.createStatement();
		
		stmt.execute(sql);
	}
	
	public int insertDataM2T3(Connection connection, OperMangPackg e) throws SQLException
	{
		String sql = "insert into CustomerM2T3 (Id,PackageName,PackageCategory,PackageChargingType,PackageTransmissionType,AddChannels,PackageCost,PackageAvailableFromDate,PackageAvailabletoDate,AddedByDefault) values (?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, e.getId());
		pstmt.setString(2, e.getPackageName());
		pstmt.setString(3, e.getPackageCategory());
		pstmt.setString(4, e.getPackageChargingType());
		pstmt.setString(5, e.getPackageTransmissionType());
		pstmt.setString(6, e.getAddChannels());
		pstmt.setString(7, e.getPackageCost());
		pstmt.setString(8, e.getPackageAvailableFromDate());
		pstmt.setString(9, e.getPackageAvailabletoDate());
		pstmt.setString(10, e.getAddedByDefault());

		int rows=pstmt.executeUpdate();
		return rows;
	}
	
	public int updateDataM2T3(Connection connection,String 	PackageName,String PackageCategory,String PackageChargingType,String PackageTransmissionType,String AddChannels,String PackageCost,String PackageAvailableFromDate,String PackageAvailabletoDate,String AddedByDefault,int Id) throws SQLException
	{
		String sql="update CustomerM2T3 set 	PackageName =?,PackageCategory =?,PackageChargingType =?,PackageTransmissionType =?,AddChannels =?,PackageCost =?,PackageAvailableFromDate =?,PackageAvailabletoDate =?,AddedByDefault =?  where Id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1,PackageName);
		ps.setString(2,PackageCategory);
		ps.setString(3, PackageChargingType);
		ps.setString(4, PackageTransmissionType);
		ps.setString(5,AddChannels);
		ps.setString(6,PackageCost);
		ps.setString(7, PackageAvailableFromDate);
		ps.setString(8, PackageAvailabletoDate);
		ps.setString(9, AddedByDefault);
		ps.setInt(10, Id);
		int updated=ps.executeUpdate();
		return updated;
		
		
	}
	
	public void deleteDataM2T3(Connection connection, int Id) throws SQLException
	{
		String sql = "delete from CustomerM2T3 where Id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, Id);
		pstmt.execute();
	}

//Module 3.:- Customer Package and Charging
//Module 3 Table 1.Purchase Set Top Box 
//for & access:- customer
//access:- admin and operator
	
	
	public void displayRecordsM3T1(Connection connection,int id) throws SQLException
	{
		String sql = "select 	CustomerName,SBTtype,STBmacId,STBserialNumber,STBprice,InstallationCharges,Deposit,Discount,Tax,AmountPayable from CustomerM3T1 where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1, id);
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("CustomerName: %s", resultObj.getString("CustomerName")));
			System.out.println(String.format("SBTtype: %s", resultObj.getString("SBTtype")));
			System.out.println(String.format("STBmacId: %s", resultObj.getString("STBmacId")));
			System.out.println(String.format("STBserialNumber: %s", resultObj.getString("STBserialNumber")));
			System.out.println(String.format("STBprice: %s", resultObj.getString("STBprice")));
			System.out.println(String.format("InstallationCharges: %s", resultObj.getString("InstallationCharges")));
			System.out.println(String.format("Deposit: %s", resultObj.getString("Deposit")));
			System.out.println(String.format("Discount: %s", resultObj.getString("Discount")));
			System.out.println(String.format("Tax: %s", resultObj.getString("Tax")));
			System.out.println(String.format("AmountPayable: %s", resultObj.getString("AmountPayable")));
		}
	}
	
	public void createTableM3T1(Connection connection) throws SQLException
	{
		String sql = "create table CustomerM3T1(Id int primary key,CustomerName varchar(25),SBTtype varchar(25),STBmacId varchar(25),STBserialNumber varchar(25),STBprice varchar(25),InstallationCharges varchar(25),Deposit varchar(25),Discount  varchar(25),Tax varchar(25),AmountPayable varchar(25) )";
		Statement stmt = connection.createStatement();
		
		stmt.execute(sql);
	}
	
	public int insertDataM3T1(Connection connection, CustPurchaseSBT e) throws SQLException
	{
		String sql = "insert into CustomerM3T1 (Id,	CustomerName,SBTtype,STBmacId,STBserialNumber,STBprice,InstallationCharges,Deposit,Discount,Tax,AmountPayable) values (?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=connection.prepareStatement(sql);
		pstmt.setInt(1, e.getId());
		pstmt.setString(2, e.getCustomerName());
		pstmt.setString(3, e.getSBTtype());
		pstmt.setString(4, e.getSTBmacId());
		pstmt.setString(5, e.getSTBserialNumber());
		pstmt.setString(6, e.getSTBprice());
		pstmt.setString(7, e.getInstallationCharges());
		pstmt.setString(8, e.getDeposit());
		pstmt.setString(9, e.getDiscount());
		pstmt.setString(10, e.getTax());
		pstmt.setString(11, e.getAmountPayable());
		
		int rows=pstmt.executeUpdate();
		return rows;
	}
	
	public int updateDataM3T1(Connection connection,String 	CustomerName,String SBTtype,String STBmacId,String STBserialNumber,String STBprice,String InstallationCharges,String Deposit,String Discount,String Tax,String AmountPayable,int Id) throws SQLException
	{
		String sql="update CustomerM3T1 set 	CustomerName =?,SBTtype =?,STBmacId =?,STBserialNumber =?,STBprice =?,InstallationCharges =?,Deposit =?,Discount =?,Tax =?,AmountPayable =? where Id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1,CustomerName);
		ps.setString(2,SBTtype);
		ps.setString(3, STBmacId);
		ps.setString(4, STBserialNumber);
		ps.setString(5,STBprice);
		ps.setString(6,InstallationCharges);
		ps.setString(7, Deposit);
		ps.setString(8, Discount);
		ps.setString(9,Tax);
		ps.setString(10,AmountPayable);
		ps.setInt(11, Id);
		int updated=ps.executeUpdate();
		return updated;
		
		
	}
	
	public void deleteDataM3T1(Connection connection, int Id) throws SQLException
	{
		String sql = "delete from CustomerM3T1 where Id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, Id);
		pstmt.execute();
	}

//Module 3 Table2.Purchase Channel Package
//for & access:- Customer
//access:- admin and operator

	public void displayRecordsM3T2(Connection connection,int id) throws SQLException
	{
		String sql = "select 	CustomerName,PackageName,ChannelName,ChannelCharge,PackagePurchaseDate,TotalPackageCost,TotalAmount from CustomerM3T2 where id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1,id);
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("CustomerName: %s", resultObj.getString("CustomerName")));
			System.out.println(String.format("PackageName: %s", resultObj.getString("PackageName")));
			System.out.println(String.format("ChannelName: %s", resultObj.getString("ChannelName")));
			System.out.println(String.format("ChannelCharge: %s",resultObj.getString("ChannelCharge")));
			System.out.println(String.format("PackagePurchaseDate: %s", resultObj.getString("PackagePurchaseDate")));
			System.out.println(String.format("TotalPackageCost: %s", resultObj.getString("TotalPackageCost")));
			System.out.println(String.format("TotalAmount: %s", resultObj.getString("TotalAmount")));
		}
	}
	
	public void createTableM3T2(Connection connection) throws SQLException
	{
		String sql = "create table CustomerM3T2(Id int primary key,CustomerName varchar(25),PackageName varchar(25),ChannelName varchar(25),ChannelCharge varchar(25),PackagePurchaseDate varchar(25),TotalPackageCost varchar(25),TotalAmount varchar(25))";
		Statement stmt = connection.createStatement();
		
		stmt.execute(sql);
	}
	
	public int insertDataM3T2(Connection connection, CustPurchaseChanlPkg e) throws SQLException
	{
		
		String sql = "insert into CustomerM3T2 (Id,	CustomerName,PackageName,ChannelName,ChannelCharge,PackagePurchaseDate,TotalPackageCost,TotalAmount) values (?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, e.getId());
		pstmt.setString(2, e.getCustomerName());
		pstmt.setString(3, e.getPackageName());
		pstmt.setString(4, e.getChannelName());
		pstmt.setString(5, e.getChannelCharge());
		pstmt.setString(6, e.getPackagePurchaseDate());
		pstmt.setString(7, e.getTotalPackageCost());
		pstmt.setString(8, e.getTotalAmount());
		
		int rows=pstmt.executeUpdate();
		return rows;
	}
	
	public int updateDataM3T2(Connection connection,String 	CustomerName,String PackageName,String ChannelName,String ChannelCharge,String PackagePurchaseDate,String TotalPackageCost,String TotalAmount,int Id) throws SQLException
	{
		String sql="update CustomerM3T2 set 	CustomerName =?,PackageName =?,ChannelName =?,ChannelCharge =?,PackagePurchaseDate =?,TotalPackageCost =?,TotalAmount =? where Id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1,CustomerName);
		ps.setString(2,PackageName);
		ps.setString(3, ChannelName);
		ps.setString(4, ChannelCharge);
		ps.setString(5,PackagePurchaseDate);
		ps.setString(6,TotalPackageCost);
		ps.setString(7, TotalAmount);
		ps.setInt(8, Id);
		int updated=ps.executeUpdate();
		return updated;
		
		
	}
	
	public void deleteDataM3T2(Connection connection, int Id) throws SQLException
	{
		String sql = "delete from CustomerM3T2 where Id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, Id);
		pstmt.execute();
	}

//Module 3 Table 3.Customer Charging
//for & access:- admin and operator

	
	public void displayRecordsM3T3(Connection connection,int id) throws SQLException
	{
		String sql = "select CustomerName,SBTtype,PackageName,PackageCost,OtherCharges,Tax,TotalAmount,BillGenerationDate,BillPaymentDate from CustomerM3T3 where Id=?";
		PreparedStatement stmpt = connection.prepareStatement(sql);
		stmpt.setInt(1,id);
		ResultSet resultObj = stmpt.executeQuery();
		
		while(resultObj.next())
		{
			System.out.println(String.format("CustomerName: %s", resultObj.getString("CustomerName")));
			System.out.println(String.format("SBTtype: %s", resultObj.getString("SBTtype")));
			System.out.println(String.format("PackageName: %s", resultObj.getString("PackageName")));
			System.out.println(String.format("PackageCost: %s", resultObj.getString("PackageCost")));
			System.out.println(String.format("OtherCharges: %s", resultObj.getString("OtherCharges")));
			System.out.println(String.format("Tax: %s", resultObj.getString("Tax")));
			System.out.println(String.format("TotalAmount: %s", resultObj.getString("TotalAmount")));
			System.out.println(String.format("BillGenerationDate: %s", resultObj.getString("BillGenerationDate")));
			System.out.println(String.format("BillPaymentDate: %s", resultObj.getString("BillPaymentDate")));
		}
	}
	
	public void createTableM3T3(Connection connection) throws SQLException
	{
		String sql = "create table CustomerM3T3(Id int primary key,CustomerName varchar(25),SBTtype varchar(25),PackageName varchar(25),PackageCost varchar(25),OtherCharges varchar(25),Tax varchar(25),TotalAmount varchar(25),BillGenerationDate varchar(25),BillPaymentDate varchar(25)  )";
		Statement stmt = connection.createStatement();
		
		stmt.execute(sql);
	}
	
	public int insertDataM3T3(Connection connection, OperCustCharg e) throws SQLException
	{
		String sql = "insert into CustomerM3T3 (Id,CustomerName,SBTtype,PackageName,PackageCost,OtherCharges,Tax,TotalAmount,BillGenerationDate,BillPaymentDate) values (?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, e.getId());
		pstmt.setString(2, e.getCustomerName());
		pstmt.setString(3, e.getSBTtype());
		pstmt.setString(4, e.getPackageName());
		pstmt.setString(5, e.getPackageCost());
		pstmt.setString(6, e.getOtherCharges());
		pstmt.setString(7, e.getTax());
		pstmt.setString(8, e.getTotalAmount());
		pstmt.setString(9, e.getBillGenerationDate());
		pstmt.setString(10, e.getBillPaymentDate());

		int rows=pstmt.executeUpdate();
		return rows;
	}
	
	public int updateDataM3T3(Connection connection,String CustomerName, String SBTtype,String PackageName,String PackageCost,String OtherCharges,String Tax,String TotalAmount,String BillGenerationDate,String BillPaymentDate,int Id) throws SQLException
	{
		String sql="update CustomerM3T3 set CustomerName =?,SBTtype =?,PackageName =?,PackageCost =?,OtherCharges =?,Tax=?,TotalAmount =?,BillGenerationDate =?,BillPaymentDate =? where Id=?";
		PreparedStatement ps=connection.prepareStatement(sql);
		ps.setString(1,CustomerName);
		ps.setString(2,PackageName);
		ps.setString(3, PackageName);
		ps.setString(4, PackageCost);
		ps.setString(5,OtherCharges);
		ps.setString(6,Tax);
		ps.setString(7, TotalAmount);
		ps.setString(8, BillGenerationDate);
		ps.setString(9, BillPaymentDate);
		ps.setInt(10, Id);
		int updated=ps.executeUpdate();
		return updated;
	
		
	}
	
	public void deleteDataM3T3(Connection connection, int Id) throws SQLException
	{
		String sql = "delete from CustomerM3T3 where Id = ?";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		pstmt.setInt(1, Id);
		pstmt.execute();
	}

}
