package com.bean;

public class CustMangSBT {
	private int Id;
	private String SBTtype;
	private String SBTfeatures;
	private  String Length;
	private String Breadth;
	private String Width;
	private  String Price;
	private String InstallationCharges;
	private String UpgradationCharges;
	private String Discount;
	private String BillingType;
	private String RefundableDepositeAmmount;
	private String SBTinventoryDetails;
	private String SBTtypeMatch;
	private String SBTserialNumber;
	private String SBTmacId;
	private String RemoteControlAssetId;
	private String DishAssetId;
	private String SBTstatus;
	public CustMangSBT(int id, String sBTtype, String sBTfeatures, String length, String breadth, String width,
			String price, String installationCharges, String upgradationCharges, String discount, String billingType,
			String refundableDepositeAmmount, String sBTinventoryDetails, String sBTtypeMatch, String sBTserialNumber,
			String sBTmacId, String remoteControlAssetId, String dishAssetId, String sBTstatus) {
		Id = id;
		SBTtype = sBTtype;
		SBTfeatures = sBTfeatures;
		Length = length;
		Breadth = breadth;
		Width = width;
		Price = price;
		InstallationCharges = installationCharges;
		UpgradationCharges = upgradationCharges;
		Discount = discount;
		BillingType = billingType;
		RefundableDepositeAmmount = refundableDepositeAmmount;
		SBTinventoryDetails = sBTinventoryDetails;
		SBTtypeMatch = sBTtypeMatch;
		SBTserialNumber = sBTserialNumber;
		SBTmacId = sBTmacId;
		RemoteControlAssetId = remoteControlAssetId;
		DishAssetId = dishAssetId;
		SBTstatus = sBTstatus;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getSBTtype() {
		return SBTtype;
	}
	public void setSBTtype(String sBTtype) {
		SBTtype = sBTtype;
	}
	public String getSBTfeatures() {
		return SBTfeatures;
	}
	public void setSBTfeatures(String sBTfeatures) {
		SBTfeatures = sBTfeatures;
	}
	public String getLength() {
		return Length;
	}
	public void setLength(String length) {
		Length = length;
	}
	public String getBreadth() {
		return Breadth;
	}
	public void setBreadth(String breadth) {
		Breadth = breadth;
	}
	public String getWidth() {
		return Width;
	}
	public void setWidth(String width) {
		Width = width;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getInstallationCharges() {
		return InstallationCharges;
	}
	public void setInstallationCharges(String installationCharges) {
		InstallationCharges = installationCharges;
	}
	public String getUpgradationCharges() {
		return UpgradationCharges;
	}
	public void setUpgradationCharges(String upgradationCharges) {
		UpgradationCharges = upgradationCharges;
	}
	public String getDiscount() {
		return Discount;
	}
	public void setDiscount(String discount) {
		Discount = discount;
	}
	public String getBillingType() {
		return BillingType;
	}
	public void setBillingType(String billingType) {
		BillingType = billingType;
	}
	public String getRefundableDepositeAmmount() {
		return RefundableDepositeAmmount;
	}
	public void setRefundableDepositeAmmount(String refundableDepositeAmmount) {
		RefundableDepositeAmmount = refundableDepositeAmmount;
	}
	public String getSBTinventoryDetails() {
		return SBTinventoryDetails;
	}
	public void setSBTinventoryDetails(String sBTinventoryDetails) {
		SBTinventoryDetails = sBTinventoryDetails;
	}
	public String getSBTtypeMatch() {
		return SBTtypeMatch;
	}
	public void setSBTtypeMatch(String sBTtypeMatch) {
		SBTtypeMatch = sBTtypeMatch;
	}
	public String getSBTserialNumber() {
		return SBTserialNumber;
	}
	public void setSBTserialNumber(String sBTserialNumber) {
		SBTserialNumber = sBTserialNumber;
	}
	public String getSBTmacId() {
		return SBTmacId;
	}
	public void setSBTmacId(String sBTmacId) {
		SBTmacId = sBTmacId;
	}
	public String getRemoteControlAssetId() {
		return RemoteControlAssetId;
	}
	public void setRemoteControlAssetId(String remoteControlAssetId) {
		RemoteControlAssetId = remoteControlAssetId;
	}
	public String getDishAssetId() {
		return DishAssetId;
	}
	public void setDishAssetId(String dishAssetId) {
		DishAssetId = dishAssetId;
	}
	public String getSBTstatus() {
		return SBTstatus;
	}
	public void setSBTstatus(String sBTstatus) {
		SBTstatus = sBTstatus;
	}
	
	
	

}
