package com.bean;

import java.util.Date;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import com.bean.CustMangSBT;
import com.bean.CustPurchaseChanlPkg;
import com.bean.CustPurchaseSBT;
import com.dao.databaselogin;

import com.bean.OperCustCharg;
import com.bean.OperMangChannel;
import com.bean.OperMangPackg;
public class function {
	databaselogin dao=new databaselogin();
	public Scanner sc;
	public Scanner sc2;
	public Scanner sc3;
	String ids="";
	public void admin(Connection connection) throws SQLException
	{
		sc3 = new Scanner(System.in);
		boolean bool1=true;
		while(bool1){
		System.out.println("1.Operator \n 2.Retailer \n 3.Customer \n 4.logout");
		int val=sc3.nextInt();
		boolean bool=true;
		switch(val)
		{
		case 1://admin operator
			while(bool){
			System.out.println("which operation you like to perform: \n 1:search \n 2:update \n 3:delete \n 4:insert \n 5:operator customer channel \n 6:operator manage package \n 7:operator customer charge \n 8:to home");
			int val1=sc3.nextInt();
			switch(val1)
			{
			case 1:
				System.out.println("Enter id");
				int id=sc3.nextInt();
				dao.displayOperatorRecords(connection, id);
				break;
			case 2:
				System.out.println("Enter id");
				int id1=sc3.nextInt();
				System.out.println("First Name");
				String firstname=sc3.next();
				System.out.println("Last Name");
				String lastname=sc3.next();
				System.out.println("Email ID");
				String emailid=sc3.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phonenumber=sc3.next();
				System.out.println("Shift Time Start enter hh:mm:am/pm format");
				String shifttimestart=sc3.next();
				int hours=Integer.parseInt(shifttimestart.substring(0, 2));
				int minutes=Integer.parseInt(shifttimestart.substring(3, 5));
				if(shifttimestart.substring(5, 7).equalsIgnoreCase("pm"))
				{
					minutes+=((hours+12+8)*60);
				}
				else
				{
					minutes+=((hours+8)*60);
				}
				String a="";
				if(minutes/60>12)
					a="pm";
				else
					a="am";
				String shifttimeend=String.valueOf(minutes/60)+":"+String.format("%02d",minutes%60)+" "+a;
				System.out.println("Shift Time End "+shifttimeend);
				System.out.println("maximum no of Customers to be managed");
				int noofcustomerstobemanaged=sc3.nextInt();
				System.out.println("Creation Date \n please enter in dd/mm/yyyy format");
				String creationdate=sc3.next();
				dao.updateDatainoperator(connection, firstname, lastname, emailid, phonenumber, shifttimestart, shifttimeend, noofcustomerstobemanaged, creationdate, id1);
				break;
			case 3:
				System.out.println("Enter id");
				int id2=sc3.nextInt();
				dao.deleteDatafromoperator(connection, id2);
				dao.deleteDatafromlogincred(connection, id2);
				break;
			case 4:
				int id3=dao.generateid();
				System.out.println("First Name");
				String first_name=sc3.next();
				System.out.println("Last Name");
				String last_name=sc3.next();
				System.out.println("Email ID");
				String email_id=sc3.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phone_number=sc3.next();
				System.out.println("Shift Time Start enter hh:mm:am/pm format dont give any spaces");
				String shift_time_start=sc3.next();
				int hour=Integer.parseInt(shift_time_start.substring(0, 2));
				int minute=Integer.parseInt(shift_time_start.substring(3, 5));
				if(shift_time_start.substring(5, 7).equalsIgnoreCase("pm"))
				{
					minute+=((hour+12+8)*60);
				}
				else
				{
					minute+=((hour+8)*60);
				}
				String a1="";
				if(minute/60>12){
					a1="pm";
				}
				else
					a1="am";
				String shift_time_end=String.valueOf(minute/60)+":"+String.format("%02d",minute%60)+" "+a1;
				System.out.println("Shift Time End "+shift_time_end);
				System.out.println("maximum no of Customers to be managed");
				int no_of_customers_to_be_managed=sc3.nextInt();
				System.out.println("Creation Date \n please enter in dd/mm/yyyy format");
				String creation_date=sc3.next();
				try{
				operator o=new operator(id3, first_name, last_name, email_id, phone_number, shift_time_start, shift_time_end, no_of_customers_to_be_managed, creation_date,0);
				logcred l=new logcred(id3,last_name,"Defpass@123","operator");
				dao.insertOperator(connection, o);
				dao.insertLoginCred(connection, l);
				}
				catch(Exception e)
				{
					id3=dao.generateid();
				}
				System.out.println("your id is"+id3);
				break;
			case 5:
				OperatorCustomerchannel(connection);
				break;
			case 6:
				OperatorManagepackage(connection);
				break;
			case 7:
				Operatorcustcharge(connection);
				break;
			case 8:
				bool=false;
				break;
			default:
				System.out.println("enter the correct input");
				break;
			}
		}
			break;
		case 2: //admin retailer
			while(bool){
			System.out.println("which operation you like to perform: \n 1:search \n 2:update \n 3:delete \n 4:insert \n 5:to home");
			int val2=sc3.nextInt();
			switch(val2)
			{
			case 1:
				System.out.println("Enter id");
				int id=sc3.nextInt();
				dao.displayRetailerRecords(connection, id);
				break;
			case 2:
				System.out.println("Enter id");
				int id1=sc3.nextInt();
				System.out.println("Name");
				String name=sc3.next();
				System.out.println("Contact No1");
				String contactno1=sc3.next();
				System.out.println("Contact No2");
				String contactno2=sc3.next();
				System.out.println("Address1");
				String address1=sc3.next();
				System.out.println("Address2");
				String address2=sc3.next();
				System.out.println("Pincode");
				String pincode=sc3.next();
				System.out.println("City");
				String city=sc3.next();
				System.out.println("State");
				String state=sc3.next();
				System.out.println("Settopboxlimit");
				int settopboxlimit=sc3.nextInt();
				System.out.println("Credit Limit");
				int creditlimit=sc3.nextInt();
				System.out.println("Commission Percentage on sale of goods");
				int commissionpercentage=sc3.nextInt();
				System.out.println("Service Charges");
				int servicecharge=sc3.nextInt();
				System.out.println("Inventory List");
				int inventorylist=id1;
				dao.updateDatainretailer(connection, name, contactno1, contactno2, address1, address2, pincode, city, state, settopboxlimit, creditlimit, commissionpercentage, servicecharge, inventorylist, id1);
				break;
			case 3:
				System.out.println("Enter id");
				int id2=sc3.nextInt();
				dao.deleteDatafromretailer(connection, id2);
				dao.deleteDatafromlogincred(connection, id2);
				break;
			case 4:
				int id3=dao.generateid();
				System.out.println("Name");
				String name_=sc3.next();
				System.out.println("Contact No1");
				String contact_no1=sc3.next();
				System.out.println("Contact No2");
				String contact_no2=sc3.next();
				System.out.println("Address1");
				String address_1=sc3.next();
				System.out.println("Address2");
				String address_2=sc3.next();
				System.out.println("Pincode");
				String pincode_=sc3.next();
				System.out.println("City");
				String city_=sc3.next();
				System.out.println("State");
				String state_=sc3.next();
				System.out.println("Settopboxlimit");
				int settop_box_limit=sc3.nextInt();
				System.out.println("Credit Limit");
				int credit_limit=sc3.nextInt();
				System.out.println("Commission Percentage on sale of goods");
				int commission_percentage=sc3.nextInt();
				System.out.println("Service Charges");
				int service_charge=sc3.nextInt();
				System.out.println("Inventory List");
				System.out.println("Set Top Box Type");
				String type=sc3.next();
				System.out.println("Set Top Box Serial number");
				int number=sc3.nextInt();
				System.out.println("Set Top Box MAC ID");
				int macid=sc3.nextInt();
				System.out.println("Remote Control asset id");
				int assetid=sc3.nextInt();
				System.out.println("Dish asset id");
				int dishassetid=sc3.nextInt();
				System.out.println("Set Top Box Status");
				String status="Unassigned";
				inventorylist i=new inventorylist(id3, type, number, macid, assetid, dishassetid, status);
				dao.insertInventorylist(connection, i);
				int inventorylist1=id3;
				System.out.println("Retailer Creation Date");
				SimpleDateFormat form=new SimpleDateFormat("dd/mm/yy");
				Date date=new Date();
				String retailercreationdate=form.format(date);
				try{
				retailer r=new retailer(id3, name_, contact_no1, contact_no2, address_1, address_2, pincode_, city_, state_, settop_box_limit, credit_limit, commission_percentage, service_charge, inventorylist1, retailercreationdate);
				logcred l=new logcred(id3, name_, "Defpass@123", "retailer");
				int x=dao.insertRetailer(connection, r);
				System.out.println(x);
				dao.insertLoginCred(connection, l);
				}
				catch(Exception e)
				{
					id3=dao.generateid();
				}
				System.out.println("your id is"+id3);
				break;
			case 5:
				bool=false;
				break;
			default:
				System.out.println("enter the correct input");
				break;
			}
			}
			break;
		case 3://admin customer
			while(bool){
			System.out.println("which operation you like to perform: \n 1:search \n 2:update \n 3:delete \n 4:insert \n 5:customer manage settop box \n 6:customer purchase settop box \n 7:customer purchase channel package \n 8:to home ");
			int val3=sc3.nextInt();
			switch(val3)
			{
			case 1:
				System.out.println("Enter id");
				int id=sc3.nextInt();
				dao.displayCustomerRecords(connection, id);
				break;
			case 2:
				System.out.println("Enter id");
				int id1=sc3.nextInt();
				System.out.println("First Name");
				String first_name=sc3.next();
				System.out.println("Last Name");
				String last_name=sc3.next();
				System.out.println("Email ID");
				String email_id=sc3.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phone_number=sc3.next();
				System.out.println("Address1");
				String address_1=sc3.next();
				System.out.println("Address2");
				String address_2=sc3.next();
				System.out.println("landmark");
				String landmark_=sc3.next();
				System.out.println("Pincode");
				String pincode_=sc3.next();
				System.out.println("City");
				String city_=sc3.next();
				System.out.println("State");
				String state_=sc3.next();
				System.out.println("Operatorname");
				String operatorname=sc3.next();
				System.out.println("Retailername");
				String retailername=sc3.next();
				dao.updateDataincustomer(connection, first_name, last_name, email_id, phone_number, address_1, address_2, landmark_, pincode_, city_, state_, operatorname, retailername, id1);
				System.out.println("details updated successfully");
				break;
			case 3:
				System.out.println("Enter id");
				int id2=sc3.nextInt();
				dao.deleteDatafromcustomer(connection, id2);
				dao.deleteDatafromlogincred(connection, id2);
				break;
			case 4:
				int id3=dao.generateid();
				System.out.println("First Name");
				String firstname=sc3.next();
				System.out.println("Last Name");
				String lastname=sc3.next();
				System.out.println("Email ID");
				String emailid=sc3.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phonenumber=sc3.next();
				System.out.println("Address1");
				String address1=sc3.next();
				System.out.println("Address2");
				String address2=sc3.next();
				System.out.println("landmark");
				String landmark=sc3.next();
				System.out.println("Pincode");
				String pincode=sc3.next();
				System.out.println("City");
				String city=sc3.next();
				System.out.println("State");
				String state=sc3.next();
				SimpleDateFormat form=new SimpleDateFormat("dd/mm/yy");
				Date date=new Date();
				String customercreationdate=form.format(date);
				System.out.println("Operatorname");
				String operatorname_=sc3.next();
				System.out.println("Retailername");
				String retailername_=sc3.next();
				try{
				customer c=new customer(id3, firstname, lastname, emailid, phonenumber, address1, address2, landmark, pincode, city, state, customercreationdate, operatorname_, retailername_);
				dao.insertCustomer(connection, c);
				logcred l=new logcred(id3, lastname, "Defpass@123", "customer");
				dao.insertLoginCred(connection, l);
				}
				catch (Exception e)
				{
					id3=dao.generateid();
				}
				System.out.println("your id is"+id3);
				break;
			case 5:
				customermanagesbt(connection);
			case 6:
				customerpurchasesbt(connection);
				break;
			case 7:
				customerpurchagechanlpkg(connection);
				break;
			case 8:
				bool=false;
				break;
			default:
				System.out.println("enter the correct input");
				break;
			}
			}
			break;
		case 4:
			bool1=false;
			break;
		default:
			System.out.println("enter the correct input");
			break;
			
		}
		}
		
}
	public void operator(Connection connection, int ide) throws SQLException
		{
			sc2 = new Scanner(System.in);
			boolean bool1=true;
			while(bool1){
			System.out.println("1.Retailer \n 2.Customer \n 3:logout");
			int val=sc2.nextInt();
			boolean bool=true;
			switch(val)
			{
			case 1:
				while(bool){
				System.out.println("which operation you like to perform: \n 1:search \n 2:update \n 3:delete \n 4:insert \n 5:operator customer channel \n 6:operator manage package \n 7:operator customer charge \n 8:to home");
				int val1=sc2.nextInt();
				switch(val1)
				{
				case 1:
					System.out.println("Enter id");
					int id=sc2.nextInt();
					dao.displayRetailerRecords(connection, id);
					break;
				case 2:
					System.out.println("Enter id");
					int id1=sc2.nextInt();
					System.out.println("Name");
					String name=sc2.next();
					System.out.println("Contact No1");
					String contactno1=sc2.next();
					System.out.println("Contact No2");
					String contactno2=sc2.next();
					System.out.println("Address1");
					String address1=sc2.next();
					System.out.println("Address2");
					String address2=sc2.next();
					System.out.println("Pincode");
					String pincode=sc2.next();
					System.out.println("City");
					String city=sc2.next();
					System.out.println("State");
					String state=sc2.next();
					System.out.println("Settopboxlimit");
					int settopboxlimit=sc2.nextInt();
					System.out.println("Credit Limit");
					int creditlimit=sc2.nextInt();
					System.out.println("Commission Percentage on sale of goods");
					int commissionpercentage=sc2.nextInt();
					System.out.println("Service Charges");
					int servicecharge=sc2.nextInt();
					System.out.println("Inventory List");
					int inventorylist=id1;
					dao.updateDatainretailer(connection, name, contactno1, contactno2, address1, address2, pincode, city, state, settopboxlimit, creditlimit, commissionpercentage, servicecharge, inventorylist, id1);
					break;
				case 3:
					System.out.println("Enter id");
					int id2=sc2.nextInt();
					dao.deleteDatafromretailer(connection, id2);
					dao.deleteDatafromlogincred(connection, id2);
					break;
				case 4:
					int id3=dao.generateid();
					System.out.println("Name");
					String name_=sc2.next();
					System.out.println("Contact No1");
					String contact_no1=sc2.next();
					System.out.println("Contact No2");
					String contact_no2=sc2.next();
					System.out.println("Address1");
					String address_1=sc2.next();
					System.out.println("Address2");
					String address_2=sc2.next();
					System.out.println("Pincode");
					String pincode_=sc2.next();
					System.out.println("City");
					String city_=sc2.next();
					System.out.println("State");
					String state_=sc2.next();
					System.out.println("Settopboxlimit");
					int settop_box_limit=sc2.nextInt();
					System.out.println("Credit Limit");
					int credit_limit=sc2.nextInt();
					System.out.println("Commission Percentage on sale of goods");
					int commission_percentage=sc2.nextInt();
					System.out.println("Service Charges");
					int service_charge=sc2.nextInt();
					System.out.println("Inventory List");
					System.out.println("Set Top Box Type");
					String type=sc2.next();
					System.out.println("Set Top Box Serial number");
					int number=sc2.nextInt();
					System.out.println("Set Top Box MAC ID");
					int macid=sc2.nextInt();
					System.out.println("Remote Control asset id");
					int assetid=sc2.nextInt();
					System.out.println("Dish asset id");
					int dishassetid=sc2.nextInt();
					System.out.println("Set Top Box Status");
					String status="Unassigned";
					inventorylist i=new inventorylist(id3, type, number, macid, assetid, dishassetid, status);
					dao.insertInventorylist(connection, i);
					int inventorylist1=id3;
					System.out.println("Retailer Creation Date");
					SimpleDateFormat form=new SimpleDateFormat("dd/mm/yy");
					Date date=new Date();
					String retailercreationdate=form.format(date);
					try{
					retailer r=new retailer(id3, name_, contact_no1, contact_no2, address_1, address_2, pincode_, city_, state_, settop_box_limit, credit_limit, commission_percentage, service_charge, inventorylist1, retailercreationdate);
					logcred l=new logcred(id3, name_, "Defpass@123", "retailer");
					dao.insertRetailer(connection, r);
					dao.insertLoginCred(connection, l);
					}
					catch(Exception e)
					{
						id3=dao.generateid();
					}
					System.out.println("your id is"+id3);
					break;
				case 5:
					OperatorCustomerchannel(connection);
					break;
				case 6:
					OperatorManagepackage(connection);
					break;
				case 7:
					Operatorcustcharge(connection);
					break;
				case 8:
					bool=false;
					break;
				default:
					System.out.println("enter the correct input");
					break;
				}
				}
				break;
			case 2://customer
				while(bool){
				System.out.println("which operation you like to perform: \n 1:search \n 2:update \n 3:delete \n 4:insert \n 5:to home");
				int val2=sc2.nextInt();
				switch(val2)
				{
				case 1:
					System.out.println("Enter id");
					int id=sc2.nextInt();
					dao.displayCustomerRecords(connection, id);
					break;
				case 2:
					System.out.println("Enter id");
					int id1=sc2.nextInt();
					System.out.println("First Name");
					String first_name=sc2.next();
					System.out.println("Last Name");
					String last_name=sc2.next();
					System.out.println("Email ID");
					String email_id=sc2.next();
					System.out.println("Phone Number \n please include +91 with your number");
					String phone_number=sc2.next();
					System.out.println("Address1");
					String address_1=sc2.next();
					System.out.println("Address2");
					String address_2=sc2.next();
					System.out.println("landmark");
					String landmark_=sc2.next();
					System.out.println("Pincode");
					String pincode_=sc2.next();
					System.out.println("City");
					String city_=sc2.next();
					System.out.println("State");
					String state_=sc2.next();
					System.out.println("Operatorname");
					String operatorname=dao.getoperatorname(connection, ide);
					System.out.println("Retailername");
					String retailername=sc2.next();
					dao.updateDataincustomer(connection, first_name, last_name, email_id, phone_number, address_1, address_2, landmark_, pincode_, city_, state_, operatorname, retailername, id1);
					break;
				case 3:
					System.out.println("Enter id");
					int id2=sc2.nextInt();
					dao.deleteDatafromcustomer(connection, id2);
					dao.deleteDatafromlogincred(connection, id2);
					break;
				case 4:
					int id3=dao.generateid();
					System.out.println("First Name");
					String firstname=sc2.next();
					System.out.println("Last Name");
					String lastname=sc2.next();
					System.out.println("Email ID");
					String emailid=sc2.next();
					System.out.println("Phone Number \n please include +91 with your number");
					String phonenumber=sc2.next();
					System.out.println("Address1");
					String address1=sc2.next();
					System.out.println("Address2");
					String address2=sc2.next();
					System.out.println("landmark");
					String landmark=sc2.next();
					System.out.println("Pincode");
					String pincode=sc2.next();
					System.out.println("City");
					String city=sc2.next();
					System.out.println("State");
					String state=sc2.next();
					SimpleDateFormat form=new SimpleDateFormat("dd/mm/yy");
					Date date=new Date();
					String customercreationdate=form.format(date);
					System.out.println("Operatorname");
					String operatorname_=sc2.next();
					System.out.println("Retailername");
					String retailername_=sc2.next();
					try{
					customer c=new customer(id3, firstname, lastname, emailid, phonenumber, address1, address2, landmark, pincode, city, state, customercreationdate, operatorname_, retailername_);
					dao.insertCustomer(connection, c);
					dao.updatetotalnoofactivecustomersinoperator(connection, id3);
					logcred l=new logcred(id3, lastname, "Defpass@123", "customer");
					dao.insertLoginCred(connection, l);
					}
					catch(Exception e)
					{
						id3=dao.generateid();
					}
					System.out.println("your id is"+id3);
					break;
				case 5:
					bool=false;
				default:
					System.out.println("enter the correct input");
					break;
				}
				break;
				}
			case 3:
				bool1=false;
				break;
			default:
				System.out.println("enter the correct input");
				break;
		}
		}
}
	public void Retailer(Connection connection) throws SQLException
		{
			sc = new Scanner(System.in);
			boolean bool=true;
			while(bool){
			System.out.println("which operation you like to perform: \n 1:search \n 2:update \n 3:delete \n 4:insert \n 5:to logout");
			int val1=sc.nextInt();
			switch(val1)
			{
			case 1:
				System.out.println("Enter id");
				int id=sc.nextInt();
				dao.displayCustomerRecords(connection, id);
				break;
			case 2:
				System.out.println("Enter id");
				int id1=sc.nextInt();
				System.out.println("First Name");
				String first_name=sc.next();
				System.out.println("Last Name");
				String last_name=sc.next();
				System.out.println("Email ID");
				String email_id=sc.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phone_number=sc.next();
				System.out.println("Address1");
				String address_1=sc.next();
				System.out.println("Address2");
				String address_2=sc.next();
				System.out.println("landmark");
				String landmark_=sc.next();
				System.out.println("Pincode");
				String pincode_=sc.next();
				System.out.println("City");
				String city_=sc.next();
				System.out.println("State");
				String state_=sc.next();
				System.out.println("Operatorname");
				String operatorname=sc.next();
				System.out.println("Retailername");
				String retailername=sc.next();
				dao.updateDataincustomer(connection, first_name, last_name, email_id, phone_number, address_1, address_2, landmark_, pincode_, city_, state_, operatorname, retailername, id1);
				break;
			case 3:
				System.out.println("Enter id");
				int id2=sc.nextInt();
				dao.deleteDatafromcustomer(connection, id2);
				dao.deleteDatafromlogincred(connection, id2);
				break;
			case 4:
				int id3=dao.generateid();
				System.out.println("First Name");
				String firstname=sc.next();
				System.out.println("Last Name");
				String lastname=sc.next();
				System.out.println("Email ID");
				String emailid=sc.next();
				System.out.println("Phone Number \n please include +91 with your number");
				String phonenumber=sc.next();
				System.out.println("Address1");
				String address1=sc.next();
				System.out.println("Address2");
				String address2=sc.next();
				System.out.println("landmark");
				String landmark=sc.next();
				System.out.println("Pincode");
				String pincode=sc.next();
				System.out.println("City");
				String city=sc.next();
				System.out.println("State");
				String state=sc.next();
				SimpleDateFormat form=new SimpleDateFormat("dd/mm/yy");
				Date date=new Date();
				String customercreationdate=form.format(date);
				System.out.println("Operatorname");
				String operatorname_=sc.next();
				System.out.println("Retailername");
				String retailername_=sc.next();
				try{
				customer c=new customer(id3, firstname, lastname, emailid, phonenumber, address1, address2, landmark, pincode, city, state, customercreationdate, operatorname_, retailername_);
				dao.insertCustomer(connection, c);
				logcred l=new logcred(id3, lastname, "Defpass@123", "customer");
				dao.insertLoginCred(connection, l);
				}
				catch(Exception e)
				{
					id3=dao.generateid();
				}
				System.out.println("your id is"+id3);
				break;
			case 5:
				bool=false;
				break;
			default:
				System.out.println("enter the correct input");
				break;
			}
			}
			
		
		}
	public void customer(Connection connection,int id) throws SQLException
	{
		Scanner sc=new Scanner(System.in);
			System.out.println("Welcome");
			boolean bool3=true;
			while(bool3)
			{
				System.out.println("which operation you like to perform: \n 1:customer manage settop box \n 2:customer purchase settop box \n 3:customer purchase channel package \n 4:display \n 5:to home ");
				int val=sc.nextInt();
				switch(val)
				{
				case 1:
					customermanagesbt(connection,id);
					break;
				case 2:
					customerpurchasesbt(connection,id);
					break;
				case 3:
					customerpurchagechanlpkg(connection,id);
					break;
				case 4:
					dao.displayCustomerRecords(connection, id);
					System.out.println("your id is"+id);
				case 5:
					bool3=false;
					break;
				default:
					System.out.println("enter correct value");
					break;
				}

			}
			
	}
	public void customermanagesbt(Connection connection) throws SQLException
	{
		System.out.println("Enter the Manage setup box details:-");
		//if(true){
		//while(true)
		//{
		Scanner sc=new Scanner(System.in);
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n3. Delete\n4. Update\n");
			int x1=sc.nextInt();
			/*if(x1==5)
			{
				break;
			}*/
			switch(x1)
			{
				case 1: 
					System.out.println("Enter ID");
					int id=sc.nextInt();
					dao.displayRecordsM2T1(connection,id);
				break;
			
				case 2: 
					System.out.println("Enter ID;");
					int ids=sc.nextInt();
					System.out.print("Enter your SBTtype: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your SBTfeatures: ");
					String b = sc.nextLine();
					System.out.print("Enter your Length: ");
					String c = sc.nextLine();
					System.out.print("Enter your Length: ");
					String d = sc.nextLine();
					System.out.print("Enter your Width: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your Price: ");
					String f = sc.nextLine();
					
					System.out.print("Enter your InstallationCharges: ");
					String g = sc.nextLine();
					System.out.print("Enter your UpgradationCharges: ");
					String h = sc.nextLine();
					
					System.out.print("Enter your Discount: ");
					String i = sc.nextLine();
					System.out.print("Enter your BillingType: ");
					String j = sc.nextLine();//String
	
					System.out.print("Enter your RefundableDepositeAmmount: ");
					String k = sc.nextLine();
					System.out.print("Enter your SBTinventoryDetails: ");
					String l = sc.nextLine();
					System.out.print("Enter your SBTtypeMatch: ");
					String m = sc.nextLine();
					System.out.print("Enter your SBTserialNumber: ");
					String n = sc.nextLine();
					
					System.out.print("Enter your SBTmacId: ");
					String o = sc.nextLine();
					System.out.print("Enter your RemoteControlAssetId: ");
					String p = sc.nextLine();
					System.out.print("Enter your DishAssetId: ");
					String q = sc.nextLine();
				
					System.out.print("Enter your SBTstatus: ");
					String r = sc.nextLine(); 
					
					CustMangSBT cc = new CustMangSBT(ids,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r);
					dao.insertDataM2T1(connection,cc);
				break;
				
				case 3:
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM2T1(connection, a3);
				break;	
				case 4:
					System.out.print("Enter your SBTtype: ");
					String a1 = sc.nextLine();
				
					System.out.print("Enter your SBTfeatures: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your Length: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your Length: ");
					String d1 = sc.nextLine();
					System.out.print("Enter your Width: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your Price: ");
					String f1 = sc.nextLine();
					
					System.out.print("Enter your InstallationCharges: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your UpgradationCharges: ");
					String h1 = sc.nextLine();
					
					System.out.print("Enter your Discount: ");
					String i1 = sc.nextLine();
					System.out.print("Enter your BillingType: ");
					String j1 = sc.nextLine();

					System.out.print("Enter your RefundableDepositeAmmount: ");
					String k1 = sc.nextLine();
					System.out.print("Enter your SBTinventoryDetails: ");
					String l1 = sc.nextLine();
					System.out.print("Enter your SBTtypeMatch: ");
					String m1 = sc.nextLine();
					System.out.print("Enter your SBTserialNumber: ");
					String n1 = sc.nextLine();
					
					System.out.print("Enter your SBTmacId: ");
					String o1 = sc.nextLine();
					System.out.print("Enter your RemoteControlAssetId: ");
					String p1 = sc.nextLine();
					System.out.print("Enter your DishAssetId: ");
					String q1 = sc.nextLine();
				
					System.out.print("Enter your SBTstatus: ");
					String r1 = sc.nextLine(); 
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM2T1(connection,a1,b1,c1,d1,e1,f1,g1,h1,i1,j1,k1,l1,m1,n1,o1,p1,q1,r1,s1);
					break;
					
				
					
			}

	}
	public void customerpurchasesbt(Connection connection)throws SQLException
	{
		System.out.println("Enter the Purchase setup box details:-");
		//if(true)
		//{
		//while(true)
		//{
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n3. Delete\n4. Update\n");
			int x2=sc.nextInt();
		/*	if(x2==5)
			{
				break;
			}*/
			switch(x2)
			{
				case 1: 
					System.out.println("Enter ID");
					int id=sc.nextInt();
					dao.displayRecordsM3T1(connection,id);
				break;
			
				case 2: 
					System.out.println("Enter ID");
					int ids=sc.nextInt();
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your SBTtype: ");
					String b = sc.nextLine();
					System.out.print("Enter your STBmacId: ");
					String c = sc.nextLine();
					System.out.print("Enter your STBserialNumber: ");
					String d = sc.nextLine();
					
					System.out.print("Enter your STBprice: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your DepInstallationChargesosit: ");
					String f = sc.nextLine();
					
					System.out.print("Enter your Deposit: ");
					String g = sc.nextLine();
					System.out.print("Enter your Discount: ");
					String h = sc.nextLine();
					
					System.out.print("Enter your Tax: ");
					String i = sc.nextLine();
					System.out.print("Enter your AmountPayable: ");
					String j = sc.nextLine();
					
					
					CustPurchaseSBT cc = new CustPurchaseSBT(ids,a,b,c,d,e,f,g,h,i,j);
					dao.insertDataM3T1(connection,cc);
				break;
				
				case 3:
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM3T1(connection, a3);
				break;	
				case 4:
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a1 = sc.nextLine();
					 
					System.out.print("Enter your SBTtype: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your STBmacId: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your STBserialNumber: ");
					String d1 = sc.nextLine();
					
					System.out.print("Enter your STBprice: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your DepInstallationChargesosit: ");
					String f1 = sc.nextLine();
					
					System.out.print("Enter your Deposit: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your Discount: ");
					String h1 = sc.nextLine();
					
					System.out.print("Enter your Tax: ");
					String i1 = sc.nextLine();
					System.out.print("Enter your AmountPayable: ");
					String j1 = sc.nextLine();
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM3T1(connection,a1,b1,c1,d1,e1,f1,g1,h1,i1,j1,s1);
					break;
					
				
					
			}
			
			
	}
	public void customerpurchagechanlpkg(Connection connection) throws SQLException
	{
		System.out.println("Enter the Purchase channel pakage setup box details:-");
		//if(true)
		//{
		//while(true)
		//{
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n3. Delete\n4. Update\n");
			int x3=sc.nextInt();
			/*if(x3==5)
			{
				break;
			}*/
			switch(x3)
			{
				case 1: 
					System.out.println("Enter id");
					int id=sc.nextInt();
					dao.displayRecordsM3T2(connection,id);
				break;
			
				case 2: 
					System.out.println("Enter id");
					int ids=sc.nextInt();
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your PackageName: ");
					String b = sc.nextLine();
					System.out.print("Enter your ChannelName: ");
					String c = sc.nextLine();
					System.out.print("Enter your ChannelCharge: ");
					String d = sc.nextLine();
					System.out.print("Enter your PackagePurchaseDate: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your TotalPackageCost: ");
					String f = sc.nextLine();
					System.out.print("Enter your TotalAmount: ");
					String g = sc.nextLine();
					
					
	
					
					
					CustPurchaseChanlPkg cc = new CustPurchaseChanlPkg(ids,a,b,c,d,e,f,g);
					dao.insertDataM3T2(connection,cc);
				break;
				
				case 3:
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM3T2(connection, a3);
				break;	
				case 4:
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a1 = sc.nextLine();
					 
					System.out.print("Enter your PackageName: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your ChannelName: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your ChannelCharge: ");
					String d1 = sc.nextLine();
					System.out.print("Enter your PackagePurchaseDate: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your TotalPackageCost: ");
					String f1 = sc.nextLine();
					System.out.print("Enter your TotalAmount: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM3T2(connection,a1,b1,c1,d1,e1,f1,g1,s1);
					break;
			}
	}
	public void OperatorCustomerchannel(Connection connection) throws SQLException
	{
		System.out.println("Enter operator manage channels details");
		//if(true)
		//{
		//while(true)
		//{
		Scanner sc=new Scanner(System.in);
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n3. Delete\n4. Update\n");
			int x4=sc.nextInt();
			/*if(x4==5)
			{
				break;
			}*/
			switch(x4)
			{
				case 1: 
					System.out.println("Enter Id");
					int id=sc.nextInt();
					dao.displayRecordsM2T2(connection,id);
				break;
			
				case 2: 
					System.out.println("Enter Id");
					int ids=sc.nextInt();
					sc.nextLine();
					System.out.print("Enter your ChannelName: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your ChannelBand: ");
					String b = sc.nextLine();
					System.out.print("Enter your VideoCarrierFrequency: ");
					String c = sc.nextLine();
					System.out.print("Enter your AudioCarrierFrequency: ");
					String d = sc.nextLine();
					System.out.print("Enter your ChannelChargeType: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your ChannelTransmissionType: ");
					String f = sc.nextLine();
					
					System.out.print("Enter your ChannelCharge: ");
					String g = sc.nextLine();
					
					
					OperMangChannel cc = new OperMangChannel(ids,a,b,c,d,e,f,g);
					dao.insertDataM2T2(connection,cc);
				break;
				
				case 3:
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM2T2(connection, a3);
				break;	
				case 4:
					sc.nextLine();
					System.out.print("Enter your ChannelName: ");
					String a1 = sc.nextLine();
					 
					System.out.print("Enter your ChannelBand: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your VideoCarrierFrequency: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your AudioCarrierFrequency: ");
					String d1 = sc.nextLine();
					System.out.print("Enter your ChannelChargeType: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your ChannelTransmissionType: ");
					String f1 = sc.nextLine();
					
					System.out.print("Enter your ChannelCharge: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM2T2(connection,a1,b1,c1,d1,e1,f1,g1,s1);
					break;
					
			}
					
			}

	
	public void OperatorManagepackage(Connection connection) throws SQLException
	{
		System.out.println("Enter the operator manage channel pkg details");
	//if(true)
	//{
	//while(true)
	//{
		Scanner sc=new Scanner(System.in);
		System.out.println("Menu");
		System.out.println("1. Display\n2. Insert\n3. Delete\n4. Update\n");
		int x5=sc.nextInt();
		/*if(x5==5)
		{
			break;
		}*/
		switch(x5)
		{
			case 1: 
				System.out.println("Enter Id");
				int id=sc.nextInt();
				dao.displayRecordsM2T3(connection,id);
			break;
		
			case 2:
				System.out.println("Enter Id");
				int ids=sc.nextInt();
				sc.nextLine();
				System.out.print("Enter your PackageName: ");
				String a = sc.nextLine();
				 
				System.out.print("Enter your PackageCategory: ");
				String b = sc.nextLine();
				System.out.print("Enter your PackageChargingType: ");
				String c = sc.nextLine();
				System.out.print("Enter your PackageTransmissionType: ");
				String d = sc.nextLine();
				System.out.print("Enter your AddChannels: ");
				String e = sc.nextLine();
				
				System.out.print("Enter your PackageCost: ");
				String f = sc.nextLine();
				System.out.print("Enter your PackageAvailableFromDate: ");
				String g = sc.nextLine();
				System.out.print("Enter your PackageAvailabletoDate: ");
				String h = sc.nextLine();
				
				
				System.out.print("Enter your AddedByDefault: ");
				String i = sc.nextLine();
				
				

				
				
				OperMangPackg cc = new OperMangPackg(ids,a,b,c,d,e,f,g,h,i);
				dao.insertDataM2T3(connection,cc);
			break;
			
			case 3:
				sc.nextLine();
				System.out.print("Enter your ID: ");
				int a3 = sc.nextInt();
				dao.deleteDataM2T3(connection, a3);
			break;	
			case 4:
				sc.nextLine();
				System.out.print("Enter your PackageName: ");
				String a1 = sc.nextLine();
				 
				System.out.print("Enter your PackageCategory: ");
				String b1 = sc.nextLine();
				System.out.print("Enter your PackageChargingType: ");
				String c1 = sc.nextLine();
				System.out.print("Enter your PackageTransmissionType: ");
				String d1 = sc.nextLine();
				System.out.print("Enter your AddChannels: ");
				String e1 = sc.nextLine();
				
				System.out.print("Enter your PackageCost: ");
				String f1 = sc.nextLine();
				System.out.print("Enter your PackageAvailableFromDate: ");
				String g1 = sc.nextLine();
				System.out.print("Enter your PackageAvailabletoDate: ");
				String h1 = sc.nextLine();
				
				
				System.out.print("Enter your AddedByDefault: ");
				String i1 = sc.nextLine();
				System.out.print("Enter your Id: ");
				int s1 = sc.nextInt();
				
				dao.updateDataM2T3(connection,a1,b1,c1,d1,e1,f1,g1,h1,i1,s1);
				break;
				
			
				
		}
	}
	public void Operatorcustcharge(Connection connection) throws SQLException
	{
		System.out.println("enter the opeartor customer charge details");
		//if(true)
		//{
		//while(true)
		//{
		Scanner sc=new Scanner(System.in);
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n3. Delete\n4. Update\n");
			int x6=sc.nextInt();
			/*if(x6==5)
			{
				break;
			}*/
			switch(x6)
			{
				case 1: 
					System.out.println("Enter Id");
					int id=sc.nextInt();
					dao.displayRecordsM3T3(connection,id);
				break;
			
				case 2: 
					System.out.println("Enter Id");
					int ids=sc.nextInt();
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your SBTtype: ");
					String b = sc.nextLine();
					System.out.print("Enter your PackageName: ");
					String c = sc.nextLine();
					System.out.print("Enter your PackageCost: ");
					String d = sc.nextLine();
					
					System.out.print("Enter your OtherCharges: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your Tax: ");
					String f = sc.nextLine();
					
					System.out.print("Enter your TotalAmount: ");
					String g = sc.nextLine();
					System.out.print("Enter your BillGenerationDate: ");
					String h = sc.nextLine();
					
					System.out.print("Enter your BillPaymentDate: ");
					String i = sc.nextLine();
					
					
					OperCustCharg cc = new OperCustCharg(ids,a,b,c,d,e,f,g,h,i);
					dao.insertDataM3T3(connection,cc);
				break;
				
				case 3:
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM3T3(connection, a3);
				break;	
				case 4:
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a1 = sc.nextLine();
					 
					System.out.print("Enter your SBTtype: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your PackageName: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your PackageCost: ");
					String d1 = sc.nextLine();
					
					System.out.print("Enter your OtherCharges: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your Tax: ");
					String f1 = sc.nextLine();
					
					System.out.print("Enter your TotalAmount: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your BillGenerationDate: ");
					String h1 = sc.nextLine();
					
					System.out.print("Enter your BillPaymentDate: ");
					String i1 = sc.nextLine();
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM3T3(connection,a1,b1,c1,d1,e1,f1,g1,h1,i1,s1);
					break;
					
			}
	}
	
	
	
	public void customermanagesbt(Connection connection,int id) throws SQLException
	{
		System.out.println("Enter the Manage setup box details:-");
		//if(true){
		//while(true)
		//{
		Scanner sc=new Scanner(System.in);
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n 3. home");
			int x1=sc.nextInt();
			/*if(x1==5)
			{
				break;
			}*/
			switch(x1)
			{
				case 1: 
					dao.displayRecordsM2T1(connection,id);
				break;
			
				case 2: 
					sc.nextLine();
					System.out.print("Enter your SBTtype: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your SBTfeatures: ");
					String b = sc.nextLine();
					System.out.print("Enter your Length: ");
					String c = sc.nextLine();
					System.out.print("Enter your Length: ");
					String d = sc.nextLine();
					System.out.print("Enter your Width: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your Price: ");
					String f = sc.nextLine();
					
					System.out.print("Enter your InstallationCharges: ");
					String g = sc.nextLine();
					System.out.print("Enter your UpgradationCharges: ");
					String h = sc.nextLine();
					
					System.out.print("Enter your Discount: ");
					String i = sc.nextLine();
					System.out.print("Enter your BillingType: ");
					String j = sc.nextLine();//String
	
					System.out.print("Enter your RefundableDepositeAmmount: ");
					String k = sc.nextLine();
					System.out.print("Enter your SBTinventoryDetails: ");
					String l = sc.nextLine();
					System.out.print("Enter your SBTtypeMatch: ");
					String m = sc.nextLine();
					System.out.print("Enter your SBTserialNumber: ");
					String n = sc.nextLine();
					
					System.out.print("Enter your SBTmacId: ");
					String o = sc.nextLine();
					System.out.print("Enter your RemoteControlAssetId: ");
					String p = sc.nextLine();
					System.out.print("Enter your DishAssetId: ");
					String q = sc.nextLine();
				
					System.out.print("Enter your SBTstatus: ");
					String r = sc.nextLine(); 
					
					CustMangSBT cc = new CustMangSBT(id,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r);
					dao.insertDataM2T1(connection,cc);
				break;
				
				case 3:
					/*sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM2T1(connection, a3);*/
				break;	
				case 4:
					/*
					System.out.print("Enter your SBTtype: ");
					String a1 = sc.nextLine();
				
					System.out.print("Enter your SBTfeatures: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your Length: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your Length: ");
					String d1 = sc.nextLine();
					System.out.print("Enter your Width: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your Price: ");
					String f1 = sc.nextLine();
					
					System.out.print("Enter your InstallationCharges: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your UpgradationCharges: ");
					String h1 = sc.nextLine();
					
					System.out.print("Enter your Discount: ");
					String i1 = sc.nextLine();
					System.out.print("Enter your BillingType: ");
					String j1 = sc.nextLine();

					System.out.print("Enter your RefundableDepositeAmmount: ");
					String k1 = sc.nextLine();
					System.out.print("Enter your SBTinventoryDetails: ");
					String l1 = sc.nextLine();
					System.out.print("Enter your SBTtypeMatch: ");
					String m1 = sc.nextLine();
					System.out.print("Enter your SBTserialNumber: ");
					String n1 = sc.nextLine();
					
					System.out.print("Enter your SBTmacId: ");
					String o1 = sc.nextLine();
					System.out.print("Enter your RemoteControlAssetId: ");
					String p1 = sc.nextLine();
					System.out.print("Enter your DishAssetId: ");
					String q1 = sc.nextLine();
				
					System.out.print("Enter your SBTstatus: ");
					String r1 = sc.nextLine(); 
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM2T1(connection,a1,b1,c1,d1,e1,f1,g1,h1,i1,j1,k1,l1,m1,n1,o1,p1,q1,r1,s1);*/
					break;
					
				
					
			}

	}
	public void customerpurchasesbt(Connection connection,int id)throws SQLException
	{
		System.out.println("Enter the Purchase setup box details:-");
		//if(true)
		//{
		//while(true)
		//{
		Scanner sc=new Scanner(System.in);
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n 3. home");
			int x2=sc.nextInt();
		/*	if(x2==5)
			{
				break;
			}*/
			switch(x2)
			{
				case 1: 

					dao.displayRecordsM3T1(connection,id);
				break;
			
				case 2: 
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your SBTtype: ");
					String b = sc.nextLine();
					System.out.print("Enter your STBmacId: ");
					String c = sc.nextLine();
					System.out.print("Enter your STBserialNumber: ");
					String d = sc.nextLine();
					
					System.out.print("Enter your STBprice: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your DepInstallationChargesosit: ");
					String f = sc.nextLine();
					
					System.out.print("Enter your Deposit: ");
					String g = sc.nextLine();
					System.out.print("Enter your Discount: ");
					String h = sc.nextLine();
					
					System.out.print("Enter your Tax: ");
					String i = sc.nextLine();
					System.out.print("Enter your AmountPayable: ");
					String j = sc.nextLine();
					
					
					CustPurchaseSBT cc = new CustPurchaseSBT(id,a,b,c,d,e,f,g,h,i,j);
					dao.insertDataM3T1(connection,cc);
				break;
				
				case 3:
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM3T1(connection, a3);
				break;	
				case 4:
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a1 = sc.nextLine();
					 
					System.out.print("Enter your SBTtype: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your STBmacId: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your STBserialNumber: ");
					String d1 = sc.nextLine();
					
					System.out.print("Enter your STBprice: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your DepInstallationChargesosit: ");
					String f1 = sc.nextLine();
					
					System.out.print("Enter your Deposit: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your Discount: ");
					String h1 = sc.nextLine();
					
					System.out.print("Enter your Tax: ");
					String i1 = sc.nextLine();
					System.out.print("Enter your AmountPayable: ");
					String j1 = sc.nextLine();
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM3T1(connection,a1,b1,c1,d1,e1,f1,g1,h1,i1,j1,s1);
					break;
					
				
					
			}
			
			
	}
	public void customerpurchagechanlpkg(Connection connection,int id) throws SQLException
	{
		System.out.println("Enter the Purchase channel pakage setup box details:-");
		//if(true)
		//{
		//while(true)
		//{
		Scanner sc=new Scanner(System.in);
			System.out.println("Menu");
			System.out.println("1. Display\n2. Insert\n3.home\n");
			int x3=sc.nextInt();
			/*if(x3==5)
			{
				break;
			}*/
			switch(x3)
			{
				case 1: 
					dao.displayRecordsM3T2(connection,id);
				break;
			
				case 2: 
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a = sc.nextLine();
					 
					System.out.print("Enter your PackageName: ");
					String b = sc.nextLine();
					System.out.print("Enter your ChannelName: ");
					String c = sc.nextLine();
					System.out.print("Enter your ChannelCharge: ");
					String d = sc.nextLine();
					System.out.print("Enter your PackagePurchaseDate: ");
					String e = sc.nextLine();
					
					System.out.print("Enter your TotalPackageCost: ");
					String f = sc.nextLine();
					System.out.print("Enter your TotalAmount: ");
					String g = sc.nextLine();
					
					
	
					
					
					CustPurchaseChanlPkg cc = new CustPurchaseChanlPkg(id,a,b,c,d,e,f,g);
					dao.insertDataM3T2(connection,cc);
				break;
				
				case 3:/*
					sc.nextLine();
					System.out.print("Enter your ID: ");
					int a3 = sc.nextInt();
					dao.deleteDataM3T2(connection, a3);*/
				break;	
				case 4:
					/*
					sc.nextLine();
					System.out.print("Enter your CustomerName: ");
					String a1 = sc.nextLine();
					 
					System.out.print("Enter your PackageName: ");
					String b1 = sc.nextLine();
					System.out.print("Enter your ChannelName: ");
					String c1 = sc.nextLine();
					System.out.print("Enter your ChannelCharge: ");
					String d1 = sc.nextLine();
					System.out.print("Enter your PackagePurchaseDate: ");
					String e1 = sc.nextLine();
					
					System.out.print("Enter your TotalPackageCost: ");
					String f1 = sc.nextLine();
					System.out.print("Enter your TotalAmount: ");
					String g1 = sc.nextLine();
					System.out.print("Enter your Id: ");
					int s1 = sc.nextInt();
					
					dao.updateDataM3T2(connection,a1,b1,c1,d1,e1,f1,g1,s1);*/
					break;
			}
	}
	
	}
		
