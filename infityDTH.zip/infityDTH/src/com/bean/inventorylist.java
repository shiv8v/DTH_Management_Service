package com.bean;

public class inventorylist {
	private int id;
	private String settopboxtype;
	private int serialnumber;
	private int macid;
	private int remoteassetid;
	private int dishassetid;
	private String settopboxstatus;
	public inventorylist(int id, String settopboxtype, int serialnumber, int macid, int remoteassetid, int dishassetid,
			String settopboxstatus) {
		super();
		this.id = id;
		this.settopboxtype = settopboxtype;
		this.serialnumber = serialnumber;
		this.macid = macid;
		this.remoteassetid = remoteassetid;
		this.dishassetid = dishassetid;
		this.settopboxstatus = settopboxstatus;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSettopboxtype() {
		return settopboxtype;
	}
	public void setSettopboxtype(String settopboxtype) {
		this.settopboxtype = settopboxtype;
	}
	public int getSerialnumber() {
		return serialnumber;
	}
	public void setSerialnumber(int serialnumber) {
		this.serialnumber = serialnumber;
	}
	public int getMacid() {
		return macid;
	}
	public void setMacid(int macid) {
		this.macid = macid;
	}
	public int getRemoteassetid() {
		return remoteassetid;
	}
	public void setRemoteassetid(int remoteassetid) {
		this.remoteassetid = remoteassetid;
	}
	public int getDishassetid() {
		return dishassetid;
	}
	public void setDishassetid(int dishassetid) {
		this.dishassetid = dishassetid;
	}
	public String getSettopboxstatus() {
		return settopboxstatus;
	}
	public void setSettopboxstatus(String settopboxstatus) {
		this.settopboxstatus = settopboxstatus;
	}
	
	
}
