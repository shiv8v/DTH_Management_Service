package com.bean;

public class CustPurchaseSBT {
	private int Id;
	private String CustomerName;
	private String SBTtype;
	private String STBmacId;
	private String STBserialNumber;
	private String STBprice;
	private String  InstallationCharges;
	private String Deposit;
	private String  Discount;
	private String Tax;
	private String AmountPayable;
	public CustPurchaseSBT(int id, String customerName, String sBTtype, String sTBmacId, String sTBserialNumber,
			String sTBprice, String installationCharges, String deposit, String discount, String tax,
			String amountPayable) {
		Id = id;
		CustomerName = customerName;
		SBTtype = sBTtype;
		STBmacId = sTBmacId;
		STBserialNumber = sTBserialNumber;
		STBprice = sTBprice;
		InstallationCharges = installationCharges;
		Deposit = deposit;
		Discount = discount;
		Tax = tax;
		AmountPayable = amountPayable;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getSBTtype() {
		return SBTtype;
	}
	public void setSBTtype(String sBTtype) {
		SBTtype = sBTtype;
	}
	public String getSTBmacId() {
		return STBmacId;
	}
	public void setSTBmacId(String sTBmacId) {
		STBmacId = sTBmacId;
	}
	public String getSTBserialNumber() {
		return STBserialNumber;
	}
	public void setSTBserialNumber(String sTBserialNumber) {
		STBserialNumber = sTBserialNumber;
	}
	public String getSTBprice() {
		return STBprice;
	}
	public void setSTBprice(String sTBprice) {
		STBprice = sTBprice;
	}
	public String getInstallationCharges() {
		return InstallationCharges;
	}
	public void setInstallationCharges(String installationCharges) {
		InstallationCharges = installationCharges;
	}
	public String getDeposit() {
		return Deposit;
	}
	public void setDeposit(String deposit) {
		Deposit = deposit;
	}
	public String getDiscount() {
		return Discount;
	}
	public void setDiscount(String discount) {
		Discount = discount;
	}
	public String getTax() {
		return Tax;
	}
	public void setTax(String tax) {
		Tax = tax;
	}
	public String getAmountPayable() {
		return AmountPayable;
	}
	public void setAmountPayable(String amountPayable) {
		AmountPayable = amountPayable;
	}
	
	
	
}
