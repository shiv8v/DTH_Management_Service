package com.bean;

public class customer {
	private int id;
	private String firstName;
	private String lastName;
	private String emailId;
	private String phoneNumber;
	private String Address1;
	private String Address2;
	private String landmark;
	private String pincode;
	private String city;
	private String state;
	private String customercreationdate;
	private String operatorname;
	private String retailername;
	public customer(int id, String firstName, String lastName, String emailId, String phoneNumber, String address1,
			String address2, String landmark, String pincode, String city, String state, String customercreationdate,
			String operatorname, String retailername) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.phoneNumber = phoneNumber;
		Address1 = address1;
		Address2 = address2;
		this.landmark = landmark;
		this.pincode = pincode;
		this.city = city;
		this.state = state;
		this.customercreationdate = customercreationdate;
		this.operatorname = operatorname;
		this.retailername = retailername;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCustomercreationdate() {
		return customercreationdate;
	}
	public void setCustomercreatoindate(String customercreatoindate) {
		this.customercreationdate = customercreatoindate;
	}
	public String getOperatorname() {
		return operatorname;
	}
	public void setOperatorname(String operatorname) {
		this.operatorname = operatorname;
	}
	public String getRetailername() {
		return retailername;
	}
	public void setRetailername(String retailername) {
		this.retailername = retailername;
	}
	
	
}
