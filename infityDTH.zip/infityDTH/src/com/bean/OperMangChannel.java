package com.bean;

public class OperMangChannel {
	private int Id;
	private String ChannelName;
	private String ChannelBand;
	private String VideoCarrierFrequency;
	private String AudioCarrierFrequency;
	private String ChannelChargeType;
	private String ChannelTransmissionType;
	private String ChannelCharge;
	public OperMangChannel(int id, String channelName, String channelBand, String videoCarrierFrequency,
			String audioCarrierFrequency, String channelChargeType, String channelTransmissionType,
			String channelCharge) {
		Id = id;
		ChannelName = channelName;
		ChannelBand = channelBand;
		VideoCarrierFrequency = videoCarrierFrequency;
		AudioCarrierFrequency = audioCarrierFrequency;
		ChannelChargeType = channelChargeType;
		ChannelTransmissionType = channelTransmissionType;
		ChannelCharge = channelCharge;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getChannelName() {
		return ChannelName;
	}
	public void setChannelName(String channelName) {
		ChannelName = channelName;
	}
	public String getChannelBand() {
		return ChannelBand;
	}
	public void setChannelBand(String channelBand) {
		ChannelBand = channelBand;
	}
	public String getVideoCarrierFrequency() {
		return VideoCarrierFrequency;
	}
	public void setVideoCarrierFrequency(String videoCarrierFrequency) {
		VideoCarrierFrequency = videoCarrierFrequency;
	}
	public String getAudioCarrierFrequency() {
		return AudioCarrierFrequency;
	}
	public void setAudioCarrierFrequency(String audioCarrierFrequency) {
		AudioCarrierFrequency = audioCarrierFrequency;
	}
	public String getChannelChargeType() {
		return ChannelChargeType;
	}
	public void setChannelChargeType(String channelChargeType) {
		ChannelChargeType = channelChargeType;
	}
	public String getChannelTransmissionType() {
		return ChannelTransmissionType;
	}
	public void setChannelTransmissionType(String channelTransmissionType) {
		ChannelTransmissionType = channelTransmissionType;
	}
	public String getChannelCharge() {
		return ChannelCharge;
	}
	public void setChannelCharge(String channelCharge) {
		ChannelCharge = channelCharge;
	}
	
 
}
