package com.bean;

public class retailer {
	private int id;
	private String name;
	private String contactno1;
	private String contactno2;
	private String address1;
	private String address2;
	private String pincode;
	private String city;
	private String state;
	private int settopboxlimit;
	private int creditlimit;
	private int commissionpercentage;
	private int servicecharge;
	private int inventorylist;
	private String retailercreationdate;
	private int totalcostofinventory;
	private String assignedtoretailer;
	public retailer(int id, String name, String contactno1, String contactno2, String address1, String address2,
			String pincode, String city, String state, int settopboxlimit, int creditlimit, int commissionpercentage,
			int servicecharge, int inventorylist, String retailercreationdate) {
		super();
		this.id = id;
		this.name = name;
		this.contactno1 = contactno1;
		this.contactno2 = contactno2;
		this.address1 = address1;
		this.address2 = address2;
		this.pincode = pincode;
		this.city = city;
		this.state = state;
		this.settopboxlimit = settopboxlimit;
		this.creditlimit = creditlimit;
		this.commissionpercentage = commissionpercentage;
		this.servicecharge = servicecharge;
		this.inventorylist = inventorylist;
		this.retailercreationdate = retailercreationdate;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactno1() {
		return contactno1;
	}
	public void setContactno1(String contactno1) {
		this.contactno1 = contactno1;
	}
	public String getContactno2() {
		return contactno2;
	}
	public void setContactno2(String contactno2) {
		this.contactno2 = contactno2;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getSettopboxlimit() {
		return settopboxlimit;
	}
	public void setSettopboxlimit(int settopboxlimit) {
		this.settopboxlimit = settopboxlimit;
	}
	public int getCreditlimit() {
		return creditlimit;
	}
	public void setCreditlimit(int creditlimit) {
		this.creditlimit = creditlimit;
	}
	public int getCommissionpercentage() {
		return commissionpercentage;
	}
	public void setCommissionpercentage(int commissionpercentage) {
		this.commissionpercentage = commissionpercentage;
	}
	public int getServicecharge() {
		return servicecharge;
	}
	public void setServicecharge(int servicecharge) {
		this.servicecharge = servicecharge;
	}
	public int getInventorylist() {
		return inventorylist;
	}
	public void setInventorylist(int inventorylist) {
		this.inventorylist = inventorylist;
	}
	public String getRetailercreationdate() {
		return retailercreationdate;
	}
	public void setRetailercreationdate(String retailercreationdate) {
		this.retailercreationdate = retailercreationdate;
	}
	public int getTotalcostofinventory() {
		return totalcostofinventory;
	}
	public void setTotalcostofinventory(int totalcostofinventory) {
		this.totalcostofinventory = totalcostofinventory;
	}
	public String getAssignedtoretailer() {
		return assignedtoretailer;
	}
	public void setAssignedtoretailer(String assignedtoretailer) {
		this.assignedtoretailer = assignedtoretailer;
	}
	
}
