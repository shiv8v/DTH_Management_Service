package com.bean;

public class OperMangPackg {
	private int Id;
	private String PackageName;
	private String PackageCategory;
	private String PackageChargingType;
	private String PackageTransmissionType;
	private String AddChannels;
	private String PackageCost;
	private String PackageAvailableFromDate;
	private String PackageAvailabletoDate;
	private String  AddedByDefault;
	public OperMangPackg(int id, String packageName, String packageCategory, String packageChargingType,
			String packageTransmissionType, String addChannels, String packageCost, String packageAvailableFromDate,
			String packageAvailabletoDate, String addedByDefault) {
		Id = id;
		PackageName = packageName;
		PackageCategory = packageCategory;
		PackageChargingType = packageChargingType;
		PackageTransmissionType = packageTransmissionType;
		AddChannels = addChannels;
		PackageCost = packageCost;
		PackageAvailableFromDate = packageAvailableFromDate;
		PackageAvailabletoDate = packageAvailabletoDate;
		AddedByDefault = addedByDefault;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getPackageName() {
		return PackageName;
	}
	public void setPackageName(String packageName) {
		PackageName = packageName;
	}
	public String getPackageCategory() {
		return PackageCategory;
	}
	public void setPackageCategory(String packageCategory) {
		PackageCategory = packageCategory;
	}
	public String getPackageChargingType() {
		return PackageChargingType;
	}
	public void setPackageChargingType(String packageChargingType) {
		PackageChargingType = packageChargingType;
	}
	public String getPackageTransmissionType() {
		return PackageTransmissionType;
	}
	public void setPackageTransmissionType(String packageTransmissionType) {
		PackageTransmissionType = packageTransmissionType;
	}
	public String getAddChannels() {
		return AddChannels;
	}
	public void setAddChannels(String addChannels) {
		AddChannels = addChannels;
	}
	public String getPackageCost() {
		return PackageCost;
	}
	public void setPackageCost(String packageCost) {
		PackageCost = packageCost;
	}
	public String getPackageAvailableFromDate() {
		return PackageAvailableFromDate;
	}
	public void setPackageAvailableFromDate(String packageAvailableFromDate) {
		PackageAvailableFromDate = packageAvailableFromDate;
	}
	public String getPackageAvailabletoDate() {
		return PackageAvailabletoDate;
	}
	public void setPackageAvailabletoDate(String packageAvailabletoDate) {
		PackageAvailabletoDate = packageAvailabletoDate;
	}
	public String getAddedByDefault() {
		return AddedByDefault;
	}
	public void setAddedByDefault(String addedByDefault) {
		AddedByDefault = addedByDefault;
	}
	
	
}
