package com.bean;

public class OperCustCharg {
	
	//postpaid customer;
	private int Id;
	private String CustomerName;
	private String SBTtype;
	private  String PackageName;
	private String PackageCost;
	private String OtherCharges;
	private String Tax;
	private String TotalAmount;
	private String BillGenerationDate;
	private String BillPaymentDate;
	public OperCustCharg(int id, String customerName, String sBTtype, String packageName, String packageCost,
			String otherCharges, String tax, String totalAmount, String billGenerationDate, String billPaymentDate) {
		Id = id;
		CustomerName = customerName;
		SBTtype = sBTtype;
		PackageName = packageName;
		PackageCost = packageCost;
		OtherCharges = otherCharges;
		Tax = tax;
		TotalAmount = totalAmount;
		BillGenerationDate = billGenerationDate;
		BillPaymentDate = billPaymentDate;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getSBTtype() {
		return SBTtype;
	}
	public void setSBTtype(String sBTtype) {
		SBTtype = sBTtype;
	}
	public String getPackageName() {
		return PackageName;
	}
	public void setPackageName(String packageName) {
		PackageName = packageName;
	}
	public String getPackageCost() {
		return PackageCost;
	}
	public void setPackageCost(String packageCost) {
		PackageCost = packageCost;
	}
	public String getOtherCharges() {
		return OtherCharges;
	}
	public void setOtherCharges(String otherCharges) {
		OtherCharges = otherCharges;
	}
	public String getTax() {
		return Tax;
	}
	public void setTax(String tax) {
		Tax = tax;
	}
	public String getTotalAmount() {
		return TotalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		TotalAmount = totalAmount;
	}
	public String getBillGenerationDate() {
		return BillGenerationDate;
	}
	public void setBillGenerationDate(String billGenerationDate) {
		BillGenerationDate = billGenerationDate;
	}
	public String getBillPaymentDate() {
		return BillPaymentDate;
	}
	public void setBillPaymentDate(String billPaymentDate) {
		BillPaymentDate = billPaymentDate;
	}
	
	
}
