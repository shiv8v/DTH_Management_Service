package com.bean;

public class CustPurchaseChanlPkg {
	private int Id;
	private String CustomerName;
	private String PackageName;
	private String ChannelName;
	private String ChannelCharge;
	private String PackagePurchaseDate;
	private String TotalPackageCost;
	private String TotalAmount;
	public CustPurchaseChanlPkg(int id, String customerName, String packageName, String channelName,
			String channelCharge, String packagePurchaseDate, String totalPackageCost, String totalAmount) {
		Id = id;
		CustomerName = customerName;
		PackageName = packageName;
		ChannelName = channelName;
		ChannelCharge = channelCharge;
		PackagePurchaseDate = packagePurchaseDate;
		TotalPackageCost = totalPackageCost;
		TotalAmount = totalAmount;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getPackageName() {
		return PackageName;
	}
	public void setPackageName(String packageName) {
		PackageName = packageName;
	}
	public String getChannelName() {
		return ChannelName;
	}
	public void setChannelName(String channelName) {
		ChannelName = channelName;
	}
	public String getChannelCharge() {
		return ChannelCharge;
	}
	public void setChannelCharge(String channelCharge) {
		ChannelCharge = channelCharge;
	}
	public String getPackagePurchaseDate() {
		return PackagePurchaseDate;
	}
	public void setPackagePurchaseDate(String packagePurchaseDate) {
		PackagePurchaseDate = packagePurchaseDate;
	}
	public String getTotalPackageCost() {
		return TotalPackageCost;
	}
	public void setTotalPackageCost(String totalPackageCost) {
		TotalPackageCost = totalPackageCost;
	}
	public String getTotalAmount() {
		return TotalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		TotalAmount = totalAmount;
	}
	
}
