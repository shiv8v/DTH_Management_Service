package com.bean;

public class operator {
	private int id;
	private String firstName;
	private String lastName;
	private String emailId;
	private String phonenumber;
	private String shifttimestart;
	private String shifttimeend;
	private int noofcustomersmanaged;
	private String creationdate;
	private int totalnoofactivecustomers;
	public operator(int id, String firstName, String lastName, String emailId, String phonenumber, String shifttimestart,
			String shifttimeend, int noofcustomersmanaged, String creationdate,int totalnoofactivecustomers) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.phonenumber=phonenumber;
		this.shifttimestart = shifttimestart;
		this.shifttimeend = shifttimeend;
		this.noofcustomersmanaged = noofcustomersmanaged;
		this.creationdate = creationdate;
		this.totalnoofactivecustomers = totalnoofactivecustomers;
	}
	public operator(int totalnoofactivecustomers){
	this.totalnoofactivecustomers = totalnoofactivecustomers;}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getShifttimestart() {
		return shifttimestart;
	}
	public void setShifttimestart(String shifttimestart) {
		this.shifttimestart = shifttimestart;
	}
	public String getShifttimeend() {
		return shifttimeend;
	}
	public void setShifttimeend(String shifttimeend) {
		this.shifttimeend = shifttimeend;
	}
	public int getNoofcustomersmanaged() {
		return noofcustomersmanaged;
	}
	public void setNoofcustomersmanaged(int noofcustomersmanaged) {
		this.noofcustomersmanaged = noofcustomersmanaged;
	}
	public String getCreationdate() {
		return creationdate;
	}
	public void setCreationdate(String creationdate) {
		this.creationdate = creationdate;
	}
	public int getTotalnoofactivecustomers() {
		return totalnoofactivecustomers;
	}
	public void setTotalnoofactivecustomers(int totalnoofactivecustomers) {
		this.totalnoofactivecustomers = totalnoofactivecustomers;
	}
	
	
}
